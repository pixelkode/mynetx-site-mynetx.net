namespace blu
{
	[ValueConversion(typeof(int), typeof(Visibility))]
	public class CountdownVisibilityConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			object collapsed;
			try
			{
				if (((int) value) > 140)
				{
					return Visibility.Visible;
				}
				collapsed = Visibility.Collapsed;
			}
			catch
			{
			}
			return collapsed;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0;
		}
	}
}