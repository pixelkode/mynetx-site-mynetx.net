namespace blu
{
	public class SettingsComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal Slider AppOpacitySlider;
		internal Slider AppRefreshSlider;
		internal CheckBox AutoLogin;
		internal ScaleTransform BubbleScaler;
		internal Grid ContentRoot;
		internal ImageButton LogOutButton;
		internal CheckBox LogSessions;
		internal Grid Rooty;
		internal ImageButton Settings;
		internal CheckBox SoundedUpdates;
		internal SettingsComponent uc;

		// Methods
		public SettingsComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
		}

		private void AutoLogin_Checked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.AutomaticallyLogin = true;
		}

		private void AutoLogin_Unchecked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.AutomaticallyLogin = false;
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at settings component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		private void Follow_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			Process.Start(e.Uri.ToString());
			e.Handled = true;
		}

		public void Hide()
		{
			((Storyboard) base.FindResource("BubbleOut")).Begin(this);
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/settingscomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void InitValues()
		{
			this.AppOpacitySlider.DataContext = Application.Current.MainWindow as MainWindow;
			this.AppRefreshSlider.DataContext = Application.Current.MainWindow as MainWindow;
			this.LogOutButton.DataContext = App.TwitterSource;
			if (App.BluCredentials.EnableLogging)
			{
				this.LogSessions.IsChecked = true;
			}
			else
			{
				this.LogSessions.IsChecked = false;
			}
			if (App.BluCredentials.AutomaticallyLogin)
			{
				this.AutoLogin.IsChecked = true;
			}
			else
			{
				this.AutoLogin.IsChecked = false;
			}
			if (App.BluCredentials.SoundedUpdates)
			{
				this.SoundedUpdates.IsChecked = true;
			}
			else
			{
				this.SoundedUpdates.IsChecked = false;
			}
		}

		private void LogOutButton_Click(object sender, RoutedEventArgs e)
		{
			if (!((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("There is no interweb connectiviy. Just shut the app down to quit.", PopupWindow.PopupWindowTypes.Error);
			}
			else if ((App.TwitterSource != null) && App.TwitterSource.get_IsLoggedIn())
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				App.TwitterSource.Logout();
				this.Hide();
			}
		}

		private void LogSessions_Checked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.EnableLogging = true;
		}

		private void LogSessions_Unchecked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.EnableLogging = false;
		}

		private void Rooty_MouseLeave(object sender, MouseEventArgs e)
		{
			this.Hide();
		}

		private void Settings_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
		}

		public void Show()
		{
			this.InitValues();
			((Storyboard) base.FindResource("BubbleIn")).Begin(this);
		}

		private void SoundedUpdates_Checked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.SoundedUpdates = true;
		}

		private void SoundedUpdates_Unchecked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.SoundedUpdates = false;
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.uc = (SettingsComponent) target;
					return;

				case 2:
					this.ContentRoot = (Grid) target;
					this.ContentRoot.MouseLeave += new MouseEventHandler(this.Rooty_MouseLeave);
					return;

				case 3:
					this.Rooty = (Grid) target;
					return;

				case 4:
					this.BubbleScaler = (ScaleTransform) target;
					return;

				case 5:
					this.AppOpacitySlider = (Slider) target;
					return;

				case 6:
					this.AppRefreshSlider = (Slider) target;
					return;

				case 7:
					this.SoundedUpdates = (CheckBox) target;
					this.SoundedUpdates.Checked += new RoutedEventHandler(this.SoundedUpdates_Checked);
					this.SoundedUpdates.Unchecked += new RoutedEventHandler(this.SoundedUpdates_Unchecked);
					return;

				case 8:
					this.LogSessions = (CheckBox) target;
					this.LogSessions.Checked += new RoutedEventHandler(this.LogSessions_Checked);
					this.LogSessions.Unchecked += new RoutedEventHandler(this.LogSessions_Unchecked);
					return;

				case 9:
					this.AutoLogin = (CheckBox) target;
					this.AutoLogin.Checked += new RoutedEventHandler(this.AutoLogin_Checked);
					this.AutoLogin.Unchecked += new RoutedEventHandler(this.AutoLogin_Unchecked);
					return;

				case 10:
					this.LogOutButton = (ImageButton) target;
					this.LogOutButton.Click += new RoutedEventHandler(this.LogOutButton_Click);
					return;

				case 11:
					((Hyperlink) target).RequestNavigate += new RequestNavigateEventHandler(this.Visit_RequestNavigate);
					return;

				case 12:
					((Hyperlink) target).RequestNavigate += new RequestNavigateEventHandler(this.Follow_RequestNavigate);
					return;

				case 13:
					((Hyperlink) target).RequestNavigate += new RequestNavigateEventHandler(this.Follow_RequestNavigate);
					return;

				case 14:
					this.Settings = (ImageButton) target;
					this.Settings.Click += new RoutedEventHandler(this.Settings_Click);
					return;
			}
			this._contentLoaded = true;
		}

		private void Visit_RequestNavigate(object sender, RequestNavigateEventArgs e)
		{
			Process.Start(e.Uri.ToString());
			e.Handled = true;
		}
	}
}