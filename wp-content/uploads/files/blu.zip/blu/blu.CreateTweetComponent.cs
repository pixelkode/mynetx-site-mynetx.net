namespace blu
{
	public class CreateTweetComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal StackPanel BubbleButtons;
		internal Image BubbleImage;
		internal ScaleTransform BubbleScaler;
		internal ImageButton CancelTweet;
		internal FlowDocument document;
		internal bluRichTextBox NewTweet;
		internal Grid Rooty;
		internal ImageButton SubmitTweet;
		internal TextBlock TheFinalCountdown;
		internal TextBlock TheFinalOverlay;
		public static readonly RoutedEvent TweetCreationFailedEvent = EventManager.RegisterRoutedEvent("TweetCreationFailed", RoutingStrategy.Bubble, typeof(TweetCreationFailedEventHandler), typeof(CreateTweetComponent));
		public static readonly RoutedEvent TweetCreationSuccessfulEvent = EventManager.RegisterRoutedEvent("TweetCreationSuccessful", RoutingStrategy.Bubble, typeof(TweetCreationSuccessfulEventHandler), typeof(CreateTweetComponent));
		internal CreateTweetComponent uc;

		// Events
		public event TweetCreationFailedEventHandler TweetCreationFailed
		{
			add
			{
				base.AddHandler(TweetCreationFailedEvent, value);
			}
			remove
			{
				base.RemoveHandler(TweetCreationFailedEvent, value);
			}
		}

		public event TweetCreationSuccessfulEventHandler TweetCreationSuccessful
		{
			add
			{
				base.AddHandler(TweetCreationSuccessfulEvent, value);
			}
			remove
			{
				base.RemoveHandler(TweetCreationSuccessfulEvent, value);
			}
		}

		// Methods
		public CreateTweetComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
			this.SubscribeToAPIEvents();
			base.Visibility = Visibility.Hidden;
		}

		[DebuggerNonUserCode]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		private void CancelTweet_Click(object sender, RoutedEventArgs e)
		{
			this.Hide();
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at create tweet component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		public void Hide()
		{
			((Storyboard) base.FindResource("BubbleOut")).Begin(this);
			((MainWindow) Application.Current.MainWindow).UIList.Focus();
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/createtweetcomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void NewTweet_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			Key key = e.Key;
			if (key != Key.Return)
			{
				if (key != Key.Escape)
				{
					return;
				}
			}
			else
			{
				this.SubmitTweet_Click(this, null);
				return;
			}
			this.Hide();
		}

		public void Show()
		{
			this.NewTweet.Clear();
			DoubleAnimation animation = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(450.0)));
			animation.Completed += delegate {
				this.NewTweet.Focus();
				this.NewTweet.SelectAll();
			};
			this.NewTweet.BeginAnimation(UIElement.OpacityProperty, animation);
			this.NewTweet.Focus();
			this.NewTweet.SelectAll();
			((Storyboard) base.FindResource("BubbleIn")).Begin(this);
		}

		private void SubmitTweet_Click(object sender, RoutedEventArgs e)
		{
			if ((this.NewTweet.TextLength > 0) && (this.NewTweet.TextLength <= 140))
			{
				if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
				{
					((MainWindow) Application.Current.MainWindow).StartWorking();
					App.TwitterSource.CreateTweet(this.NewTweet.PlainText);
					this.Hide();
				}
				else
				{
					TwitterDataCreationFailedEventArgs args = new TwitterDataCreationFailedEventArgs(TweetCreationFailedEvent, this, "Internet connectivity lost.");
					base.RaiseEvent(args);
				}
			}
		}

		public void SubscribeToAPIEvents()
		{
			App.TwitterSource.add_TweetCreated(new TweetCreatedHandler(this, (IntPtr) this.TwitterSource_TweetCreated));
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.uc = (CreateTweetComponent) target;
					return;

				case 2:
					this.Rooty = (Grid) target;
					return;

				case 3:
					this.BubbleScaler = (ScaleTransform) target;
					return;

				case 4:
					this.BubbleImage = (Image) target;
					return;

				case 5:
					this.TheFinalCountdown = (TextBlock) target;
					return;

				case 6:
					this.TheFinalOverlay = (TextBlock) target;
					return;

				case 7:
					this.NewTweet = (bluRichTextBox) target;
					return;

				case 8:
					this.document = (FlowDocument) target;
					return;

				case 9:
					this.BubbleButtons = (StackPanel) target;
					return;

				case 10:
					this.SubmitTweet = (ImageButton) target;
					this.SubmitTweet.Click += new RoutedEventHandler(this.SubmitTweet_Click);
					return;

				case 11:
					this.CancelTweet = (ImageButton) target;
					this.CancelTweet.Click += new RoutedEventHandler(this.CancelTweet_Click);
					return;
			}
			this._contentLoaded = true;
		}

		private void TwitterSource_TweetCreated(object sender, TwitterDataCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				TwitterDataCreationSuccessfulEventArgs args = new TwitterDataCreationSuccessfulEventArgs(TweetCreationSuccessfulEvent, this, e.get_NewTwitterData());
				base.RaiseEvent(args);
			}
			else
			{
				TwitterDataCreationFailedEventArgs args2 = new TwitterDataCreationFailedEventArgs(TweetCreationFailedEvent, this, e.get_FailureDetails());
				base.RaiseEvent(args2);
			}
		}

		// Nested Types
		public delegate void TweetCreationFailedEventHandler(object sender, TwitterDataCreationFailedEventArgs e);

		public delegate void TweetCreationSuccessfulEventHandler(object sender, TwitterDataCreationSuccessfulEventArgs e);
	}
}