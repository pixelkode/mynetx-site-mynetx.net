namespace blu
{
	[ValueConversion(typeof(double), typeof(double))]
	public class OffsetConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			try
			{
				return -((double) value);
			}
			catch
			{
			}
			return 0.0;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0.0;
		}
	}
}