namespace blu
{
	[ValueConversion(typeof(double), typeof(Visibility))]
	public class TwitterDataConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			try
			{
				if (((double) value) == -1.0)
				{
					return Visibility.Collapsed;
				}
			}
			catch
			{
			}
			return Visibility.Visible;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0.0;
		}
	}
}