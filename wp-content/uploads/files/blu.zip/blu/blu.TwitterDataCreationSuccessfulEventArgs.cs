namespace blu
{
	public class TwitterDataCreationSuccessfulEventArgs : RoutedEventArgs
	{
		// Fields
		private TwitterData newTwitterData;

		// Methods
		public TwitterDataCreationSuccessfulEventArgs(RoutedEvent id, object source, TwitterData newTwitterData) : base(id, source)
		{
			this.newTwitterData = newTwitterData;
		}

		// Properties
		public TwitterData NewTwitterData
		{
			get
			{
				return this.newTwitterData;
			}
		}
	}
}