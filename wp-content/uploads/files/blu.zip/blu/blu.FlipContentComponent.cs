namespace blu
{
	public class FlipContentComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal Image BubbleImage;
		internal ScaleTransform BubbleScaler;
		internal StackPanel Buttons;
		internal ImageButton CancelTweet;
		internal Grid CreateHolder;
		internal Grid CreateUserImageContainer;
		internal FlowDocument document;
		public static readonly DependencyProperty FlipContentTypeProperty = DependencyProperty.Register("FlipContentType", typeof(FlipComponent.FlipContentTypes), typeof(FlipContentComponent), new FrameworkPropertyMetadata(new PropertyChangedCallback(FlipContentComponent.OnFlipContentTypeChanged)));
		internal bluRichTextBox NewTweet;
		internal ContentControl NotFound;
		internal ContentControl Private;
		internal ImageButton SubmitTweet;
		internal Grid TextBubble;
		internal ScaleTransform TextBubbleScaler;
		internal TextBlock TheFinalCountdown;
		internal TextBlock TheFinalOverlay;
		internal Grid TweetDTUserImageGrid;
		internal Grid Viewable;
		internal Grid ViewReplyExiter;
		internal Grid ViewReplyHolder;

		// Methods
		public FlipContentComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
		}

		[DebuggerNonUserCode]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		public void BubbleDown()
		{
			((Storyboard) base.FindResource("BubbleOut")).Begin(this);
		}

		public void BubbleUp()
		{
			this.CreateUserImageContainer.DataContext = App.LoggedInUser;
			((Storyboard) base.FindResource("BubbleIn")).Begin(this);
			DoubleAnimation animation = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(500.0)));
			animation.BeginTime = new TimeSpan?(TimeSpan.FromMilliseconds(800.0));
			animation.Completed += delegate {
				this.NewTweet.Focus();
				this.NewTweet.CaretPosition = this.NewTweet.Document.ContentEnd;
			};
			this.NewTweet.BeginAnimation(UIElement.OpacityProperty, animation);
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at flip content component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/flipitems/flipcontentcomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private static void OnFlipContentTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			FlipContentComponent component = d as FlipContentComponent;
			if (component != null)
			{
				switch (((FlipComponent.FlipContentTypes) e.NewValue))
				{
					case FlipComponent.FlipContentTypes.ViewReply:
						component.CreateHolder.Visibility = Visibility.Collapsed;
						component.ViewReplyHolder.Visibility = Visibility.Visible;
						component.Viewable.Visibility = Visibility.Visible;
						component.NotFound.Visibility = Visibility.Collapsed;
						component.Private.Visibility = Visibility.Collapsed;
						return;

					case FlipComponent.FlipContentTypes.ViewReplyNotFound:
						component.CreateHolder.Visibility = Visibility.Collapsed;
						component.ViewReplyHolder.Visibility = Visibility.Visible;
						component.Viewable.Visibility = Visibility.Collapsed;
						component.NotFound.Visibility = Visibility.Visible;
						component.Private.Visibility = Visibility.Collapsed;
						return;

					case FlipComponent.FlipContentTypes.ViewReplyPrivate:
						component.CreateHolder.Visibility = Visibility.Collapsed;
						component.ViewReplyHolder.Visibility = Visibility.Visible;
						component.Viewable.Visibility = Visibility.Collapsed;
						component.NotFound.Visibility = Visibility.Collapsed;
						component.Private.Visibility = Visibility.Visible;
						return;

					case FlipComponent.FlipContentTypes.CreateReply:
					case FlipComponent.FlipContentTypes.CreateRetweet:
						component.CreateHolder.Visibility = Visibility.Visible;
						component.ViewReplyHolder.Visibility = Visibility.Collapsed;
						return;

					case FlipComponent.FlipContentTypes.CreateDirectMessage:
						component.CreateHolder.Visibility = Visibility.Visible;
						component.ViewReplyHolder.Visibility = Visibility.Collapsed;
						return;

					default:
						return;
				}
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.BubbleScaler = (ScaleTransform) target;
					return;

				case 2:
					this.CreateHolder = (Grid) target;
					return;

				case 3:
					this.TextBubble = (Grid) target;
					return;

				case 4:
					this.TextBubbleScaler = (ScaleTransform) target;
					return;

				case 5:
					this.BubbleImage = (Image) target;
					return;

				case 6:
					this.TheFinalCountdown = (TextBlock) target;
					return;

				case 7:
					this.TheFinalOverlay = (TextBlock) target;
					return;

				case 8:
					this.NewTweet = (bluRichTextBox) target;
					return;

				case 9:
					this.document = (FlowDocument) target;
					return;

				case 10:
					this.Buttons = (StackPanel) target;
					return;

				case 11:
					this.SubmitTweet = (ImageButton) target;
					return;

				case 12:
					this.CancelTweet = (ImageButton) target;
					return;

				case 13:
					this.CreateUserImageContainer = (Grid) target;
					return;

				case 14:
					this.ViewReplyHolder = (Grid) target;
					return;

				case 15:
					this.Viewable = (Grid) target;
					return;

				case 0x10:
					this.ViewReplyExiter = (Grid) target;
					return;

				case 0x11:
					this.TweetDTUserImageGrid = (Grid) target;
					return;

				case 0x12:
					this.NotFound = (ContentControl) target;
					return;

				case 0x13:
					this.Private = (ContentControl) target;
					return;
			}
			this._contentLoaded = true;
		}

		// Properties
		public FlipComponent.FlipContentTypes FlipContentType
		{
			get
			{
				return (FlipComponent.FlipContentTypes) base.GetValue(FlipContentTypeProperty);
			}
			set
			{
				base.SetValue(FlipContentTypeProperty, value);
			}
		}
	}
}