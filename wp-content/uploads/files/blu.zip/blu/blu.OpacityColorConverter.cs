namespace blu
{
	[ValueConversion(typeof(double), typeof(Color))]
	public class OpacityColorConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			byte num;
			Color color = new Color();
			color.A = 0;
			color.B = (byte) (num = 0xff);
			color.R = color.G = num;
			try
			{
				color.A = (byte) (255.0 - (((double) value) * 255.0));
			}
			catch
			{
			}
			return color;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0.0;
		}
	}
}