namespace blu
{
	public class TwitterDataCreationFailedEventArgs : RoutedEventArgs
	{
		// Fields
		private string failureReason;

		// Methods
		public TwitterDataCreationFailedEventArgs(RoutedEvent id, object source, string failureReason) : base(id, source)
		{
			this.failureReason = failureReason;
		}

		// Properties
		public string FailureReason
		{
			get
			{
				return this.failureReason;
			}
		}
	}
}