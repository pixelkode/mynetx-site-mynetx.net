namespace blu
{
	public class bluRichTextBox : RichTextBox
	{
		// Fields
		private static readonly RoutedUICommand[] _formattingCommands = new RoutedUICommand[] { EditingCommands.ToggleBold, EditingCommands.ToggleItalic, EditingCommands.ToggleUnderline, EditingCommands.ToggleSubscript, EditingCommands.ToggleSuperscript, EditingCommands.IncreaseFontSize, EditingCommands.DecreaseFontSize, EditingCommands.ToggleBullets, EditingCommands.ToggleNumbering };
		private List<Word> _words = new List<Word>();
		private int hiddenTinyUrlCount;
		private bool ignoreUrlShortening;
		private string pastedText = string.Empty;
		private TextPointer selectionEndPosition;
		private TextPointer selectionStartPosition;
		public static DependencyProperty TextLengthProperty = DependencyProperty.Register("TextLength", typeof(int), typeof(bluRichTextBox));
		private static readonly Dictionary<string, string> twitterNamesDictionary;
		public static Regex urlCheck = new Regex(@"^(?#Protocol)(?:(?:ht|f)tp(?:s?)\:\/\/|~/|/)?(?#Username:Password)(?:\w+:\w+@)?(?#Subdomains)(?:(?:[-\w]+\.)+(?#TopLevel Domains)(?:com|org|net|gov|mil|biz|info|mobi|name|aero|jobs|museum|travel|[a-z]{2}))(?#Port)(?::[\d]{1,5})?(?#Directories)(?:(?:(?:/(?:[-\w~!$+|.,=]|%[a-f\d]{2})+)+|/)+|\?|#)?(?#Query)(?:(?:\?(?:[-\w~!$+|.,*:]|%[a-f\d{2}])+=(?:[-\w~!$+|.,*:=]|%[a-f\d]{2})*)(?:&(?:[-\w~!$+|.,*:]|%[a-f\d{2}])+=(?:[-\w~!$+|.,*:=]|%[a-f\d]{2})*)*)*(?#Anchor)(?:#(?:[-\w~!$+|.,*:=]|%[a-f\d]{2})*)?$");
		private bool wordsAddedFlag;

		// Methods
		static bluRichTextBox()
		{
			RegisterCommandHandlers();
			EventManager.RegisterClassHandler(typeof(bluRichTextBox), UIElement.KeyDownEvent, new KeyEventHandler(bluRichTextBox.OnKeyDown), true);
			twitterNamesDictionary = new Dictionary<string, string>();
		}

		public bluRichTextBox()
		{
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler);
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler2);
			DataObject.AddPastingHandler(this, new DataObjectPastingEventHandler(this.DataObjectPastingEventHandler));
		}

		private void AddMatchingWordsInRun(Run run)
		{
			string text = run.Text;
			int startIndex = 0;
			int num2 = 0;
			for (int i = 0; i < text.Length; i++)
			{
				if (char.IsWhiteSpace(text[i]))
				{
					if ((i > 0) && !char.IsWhiteSpace(text[i - 1]))
					{
						num2 = i - 1;
						string str2 = text.Substring(startIndex, (num2 - startIndex) + 1);
						if (twitterNamesDictionary.ContainsKey(str2))
						{
							TextPointer positionAtOffset = run.ContentStart.GetPositionAtOffset(startIndex, LogicalDirection.Forward);
							TextPointer wordEnd = run.ContentStart.GetPositionAtOffset(num2 + 1, LogicalDirection.Backward);
							this._words.Add(new Word(positionAtOffset, wordEnd));
						}
					}
					startIndex = i + 1;
				}
			}
			string key = text.Substring(startIndex, text.Length - startIndex);
			if (twitterNamesDictionary.ContainsKey(key))
			{
				TextPointer wordStart = run.ContentStart.GetPositionAtOffset(startIndex, LogicalDirection.Forward);
				TextPointer pointer4 = run.ContentStart.GetPositionAtOffset(text.Length, LogicalDirection.Backward);
				this._words.Add(new Word(wordStart, pointer4));
			}
		}

		private void ChangeHiddenTinyUrlCount(int delta)
		{
			this.hiddenTinyUrlCount += delta;
			base.SetValue(TextLengthProperty, this.GetLength() + this.hiddenTinyUrlCount);
		}

		public void Clear()
		{
			TextRange range = new TextRange(base.Document.ContentStart, base.Document.ContentEnd);
			if (((range != null) && (range.Start.Paragraph != null)) && (range.Text.Length > 0))
			{
				foreach (Inline inline in range.Start.Paragraph.Inlines)
				{
					if (inline is InlineUIContainer)
					{
						InlineUIContainer container = inline as InlineUIContainer;
						(container.Child as TinyUrlBlock).Unloaded -= new RoutedEventHandler(this.tinyUrlBlock_Unloaded);
					}
				}
			}
			base.Document.Blocks.Clear();
			if (this.hiddenTinyUrlCount > 0)
			{
				this.ChangeHiddenTinyUrlCount(this.hiddenTinyUrlCount * -1);
			}
			else
			{
				this.ChangeHiddenTinyUrlCount(this.hiddenTinyUrlCount);
			}
			this._words.Clear();
			this.TwitterNamesDictionary.Clear();
		}

		private void DataObjectPastingEventHandler(object sender, DataObjectPastingEventArgs e)
		{
			bool flag = false;
			foreach (string str in e.DataObject.GetFormats())
			{
				if (str == DataFormats.Text)
				{
					flag = true;
				}
			}
			if (!flag)
			{
				e.CancelCommand();
			}
		}

		private void FormatWords()
		{
			base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler);
			foreach (Word word in this._words)
			{
				new TextRange(word.Start, word.End).ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush((Color) ColorConverter.ConvertFromString("#26e4ff")));
			}
			this._words.Clear();
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler);
		}

		private int GetLength()
		{
			TextRange range = new TextRange(base.Document.ContentStart, base.Document.ContentEnd);
			int length = range.Text.Length;
			if (range.Text.EndsWith(Environment.NewLine))
			{
				length -= Environment.NewLine.Length;
			}
			return length;
		}

		private string GetTextOnlyString()
		{
			StringBuilder builder = new StringBuilder();
			TextRange range = new TextRange(base.Document.ContentStart, base.Document.ContentEnd);
			if (((range != null) && (range.Start.Paragraph != null)) && (range.Text.Length > 0))
			{
				foreach (Inline inline in range.Start.Paragraph.Inlines)
				{
					if (inline is Run)
					{
						builder.Append(inline.ContentStart.GetTextInRun(LogicalDirection.Forward));
					}
					else if (inline is InlineUIContainer)
					{
						InlineUIContainer container = inline as InlineUIContainer;
						builder.Append((container.Child as TinyUrlBlock).TinyUrl);
					}
				}
			}
			return builder.ToString();
		}

		public void InitializeWithString(string initialContent)
		{
			this.wordsAddedFlag = true;
			this.ignoreUrlShortening = true;
			this.selectionStartPosition = base.Selection.Start;
			this.selectionEndPosition = base.Selection.IsEmpty ? base.Selection.End.GetPositionAtOffset(0, LogicalDirection.Forward) : base.Selection.End;
			this.selectionStartPosition = base.Document.ContentStart;
			this.selectionEndPosition = base.Document.ContentEnd;
			base.Selection.Text = initialContent;
		}

		private static void OnCanExecuteFormattingCommand(object target, CanExecuteRoutedEventArgs args)
		{
			args.CanExecute = true;
		}

		private static void OnCanExecutePaste(object target, CanExecuteRoutedEventArgs args)
		{
			bluRichTextBox box = (bluRichTextBox) target;
			args.CanExecute = (box.IsEnabled && !box.IsReadOnly) && Clipboard.ContainsText();
		}

		private static void OnFormattingCommand(object sender, ExecutedRoutedEventArgs e)
		{
			e.Handled = true;
		}

		private static void OnKeyDown(object sender, KeyEventArgs e)
		{
			bluRichTextBox box = (bluRichTextBox) sender;
			if (((e.Key == Key.Back) || (e.Key == Key.Space)) || (e.Key == Key.Return))
			{
				if (!box.Selection.IsEmpty)
				{
					box.Selection.Text = string.Empty;
				}
				TextPointer start = box.Selection.Start;
				if ((e.Key == Key.Space) || (e.Key == Key.Return))
				{
					box.GetLength();
					int hiddenTinyUrlCount = box.hiddenTinyUrlCount;
					if (e.Key == Key.Return)
					{
						e.Handled = true;
					}
					else
					{
						box.wordsAddedFlag = true;
						box.selectionStartPosition = box.Selection.Start;
						box.selectionEndPosition = box.Selection.End.GetPositionAtOffset(0, LogicalDirection.Forward);
					}
				}
				else
				{
					Hyperlink hyperlink;
					TextPointer nextInsertionPosition = start.GetNextInsertionPosition(LogicalDirection.Backward);
					if ((nextInsertionPosition != null) && HyperlinkHelper.IsHyperlinkBoundaryCrossed(start, nextInsertionPosition, out hyperlink))
					{
						TextPointer positionAtOffset = start.GetPositionAtOffset(0, LogicalDirection.Forward);
						InlineCollection inlines = hyperlink.Inlines;
						Inline[] array = new Inline[inlines.Count];
						inlines.CopyTo(array, 0);
						for (int i = array.Length - 1; i >= 0; i--)
						{
							inlines.Remove(array[i]);
							hyperlink.SiblingInlines.InsertAfter(hyperlink, array[i]);
						}
						LocalValueEnumerator localValueEnumerator = hyperlink.GetLocalValueEnumerator();
						TextRange range = new TextRange(array[0].ContentStart, array[array.Length - 1].ContentEnd);
						while (localValueEnumerator.MoveNext())
						{
							LocalValueEntry current = localValueEnumerator.Current;
							DependencyProperty dp = current.Property;
							object obj2 = current.Value;
							if (((!dp.ReadOnly && (dp != Inline.TextDecorationsProperty)) && ((dp != TextElement.ForegroundProperty) && (dp != BaseUriHelper.BaseUriProperty))) && !HyperlinkHelper.IsHyperlinkProperty(dp))
							{
								range.ApplyPropertyValue(dp, obj2);
							}
						}
						hyperlink.SiblingInlines.Remove(hyperlink);
						box.Selection.Select(positionAtOffset, positionAtOffset);
					}
				}
			}
		}

		private static void OnPaste(object sender, ExecutedRoutedEventArgs e)
		{
			bluRichTextBox box = (bluRichTextBox) sender;
			box.wordsAddedFlag = true;
			box.selectionStartPosition = box.Selection.Start;
			box.selectionEndPosition = box.Selection.IsEmpty ? box.Selection.End.GetPositionAtOffset(0, LogicalDirection.Forward) : box.Selection.End;
			if (box.TextLength == 0)
			{
				box.selectionStartPosition = box.Document.ContentStart;
				box.selectionEndPosition = box.Document.ContentEnd;
			}
			new TextRange(box.selectionEndPosition, box.selectionEndPosition);
			if (Clipboard.ContainsText())
			{
				box.pastedText = Clipboard.GetText();
				box.Selection.Text = box.pastedText;
			}
			TextPointer nextInsertionPosition = box.Selection.End.GetNextInsertionPosition(LogicalDirection.Forward);
			if (nextInsertionPosition != null)
			{
				box.CaretPosition = nextInsertionPosition;
			}
			else
			{
				box.CaretPosition = box.Selection.End;
			}
			e.Handled = false;
		}

		private void ParseForFormatting()
		{
			new TextRange(base.Document.ContentStart, base.Document.ContentEnd).ClearAllProperties();
			for (TextPointer pointer = base.Document.ContentStart; pointer.CompareTo(base.Document.ContentEnd) < 0; pointer = pointer.GetNextContextPosition(LogicalDirection.Forward))
			{
				if ((pointer.GetPointerContext(LogicalDirection.Backward) == TextPointerContext.ElementStart) && (pointer.Parent is Run))
				{
					this.AddMatchingWordsInRun((Run) pointer.Parent);
				}
			}
			this.FormatWords();
		}

		private static void RegisterCommandHandlers()
		{
			foreach (RoutedUICommand command in _formattingCommands)
			{
				CommandManager.RegisterClassCommandBinding(typeof(bluRichTextBox), new CommandBinding(command, new ExecutedRoutedEventHandler(bluRichTextBox.OnFormattingCommand), new CanExecuteRoutedEventHandler(bluRichTextBox.OnCanExecuteFormattingCommand)));
			}
			CommandManager.RegisterClassCommandBinding(typeof(bluRichTextBox), new CommandBinding(ApplicationCommands.Paste, new ExecutedRoutedEventHandler(bluRichTextBox.OnPaste), new CanExecuteRoutedEventHandler(bluRichTextBox.OnCanExecutePaste)));
		}

		private void TextChangedEventHandler(object sender, TextChangedEventArgs e)
		{
			if (this.wordsAddedFlag && (base.Document != null))
			{
				base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler);
				TextPointer selectionStartPosition = this.selectionStartPosition;
				while ((selectionStartPosition != null) && (selectionStartPosition.CompareTo(this.selectionEndPosition) <= 0))
				{
					TextRange wordRange = WordBreaker.GetWordRange(selectionStartPosition);
					if (wordRange != null)
					{
						bool isEmpty = wordRange.IsEmpty;
					}
					string text = wordRange.Text;
					if (text.Length > this.pastedText.Length)
					{
						string[] strArray = this.pastedText.Split(new string[] { " " }, StringSplitOptions.None);
						if (((strArray != null) && (strArray.Length > 0)) && urlCheck.IsMatch(strArray[0]))
						{
							TextPointer positionAtOffset = wordRange.End.GetPositionAtOffset(this.pastedText.Length * -1, LogicalDirection.Backward);
							positionAtOffset.InsertTextInRun(" ");
							wordRange = new TextRange(positionAtOffset.GetPositionAtOffset(1, LogicalDirection.Forward), wordRange.End);
							text = wordRange.Text;
						}
					}
					this.GetLength();
					int length = text.Length;
					bool flag = urlCheck.IsMatch(text);
					if (((flag && (text.Length > 0x19)) && (!this.ignoreUrlShortening && !HyperlinkHelper.IsInHyperlinkScope(wordRange.Start))) && !HyperlinkHelper.IsInHyperlinkScope(wordRange.End))
					{
						base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler2);
						TinyUrlBlock childUIElement = new TinyUrlBlock(wordRange.Text);
						childUIElement.RemoveTinyUrl += new EventHandler(this.tinyUrlBlock_RemoveTinyUrl);
						childUIElement.TinyUrlChanged += new EventHandler(this.tinyUrlBlock_TinyUrlChanged);
						childUIElement.Unloaded += new RoutedEventHandler(this.tinyUrlBlock_Unloaded);
						childUIElement.Tag = wordRange.Start;
						this.ChangeHiddenTinyUrlCount(0x16);
						wordRange.Start.DeleteTextInRun(wordRange.Start.GetOffsetToPosition(wordRange.End));
						InlineUIContainer container = new InlineUIContainer(childUIElement, wordRange.Start);
						base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler2);
						selectionStartPosition = container.ElementEnd.GetNextInsertionPosition(LogicalDirection.Forward);
						if (selectionStartPosition == null)
						{
							new Run(" ", base.Document.ContentEnd);
							TextPointer nextInsertionPosition = base.CaretPosition.GetNextInsertionPosition(LogicalDirection.Forward);
							if (nextInsertionPosition != null)
							{
								base.CaretPosition = nextInsertionPosition;
							}
						}
					}
					else
					{
						if (flag)
						{
							if (this.ignoreUrlShortening)
							{
								if (!twitterNamesDictionary.ContainsKey(text))
								{
									twitterNamesDictionary.Add(text, string.Empty);
								}
							}
							else if ((text.Length <= 0x19) && !twitterNamesDictionary.ContainsKey(text))
							{
								twitterNamesDictionary.Add(text, string.Empty);
							}
						}
						selectionStartPosition = wordRange.End.GetNextInsertionPosition(LogicalDirection.Forward);
					}
				}
				base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler);
				this.wordsAddedFlag = false;
				this.ignoreUrlShortening = false;
				this.selectionStartPosition = null;
				this.selectionEndPosition = null;
				this.ParseForFormatting();
			}
		}

		private void TextChangedEventHandler2(object sender, TextChangedEventArgs e)
		{
			new TextRange(base.Document.ContentStart, base.Document.ContentEnd);
			int num = this.GetLength() + this.hiddenTinyUrlCount;
			base.SetValue(TextLengthProperty, num);
			base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler2);
			foreach (TextChange change in e.Changes)
			{
				if (change.AddedLength == Environment.NewLine.Length)
				{
					TextRange range = new TextRange(base.Document.ContentStart.GetPositionAtOffset(change.Offset), base.Document.ContentStart.GetPositionAtOffset(change.Offset + change.AddedLength));
					if (range.Text == Environment.NewLine)
					{
						base.CaretPosition.DeleteTextInRun(change.AddedLength * -1);
					}
				}
			}
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler2);
		}

		private void tinyUrlBlock_RemoveTinyUrl(object sender, EventArgs e)
		{
			TinyUrlBlock block = sender as TinyUrlBlock;
			block.RemoveTinyUrl -= new EventHandler(this.tinyUrlBlock_RemoveTinyUrl);
			block.TinyUrlChanged -= new EventHandler(this.tinyUrlBlock_TinyUrlChanged);
			block.Unloaded -= new RoutedEventHandler(this.tinyUrlBlock_Unloaded);
			TextPointer tag = block.Tag as TextPointer;
			base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler2);
			base.TextChanged -= new TextChangedEventHandler(this.TextChangedEventHandler);
			if (block.IsTinyUrlUpdated)
			{
				if (block.TinyUrl.Length > 0)
				{
					this.ChangeHiddenTinyUrlCount(block.TinyUrl.Length * -1);
				}
			}
			else
			{
				this.ChangeHiddenTinyUrlCount(-22);
			}
			if (tag.Paragraph == null)
			{
				tag = base.Document.ContentStart;
				while (tag.Paragraph == null)
				{
					tag = tag.GetInsertionPosition(LogicalDirection.Forward);
				}
			}
			TextPointer contentStart = tag;
			foreach (Inline inline in tag.Paragraph.Inlines)
			{
				if (inline == block.Parent)
				{
					contentStart = inline.ContentStart;
				}
			}
			tag.Paragraph.Inlines.Remove(block.Parent as InlineUIContainer);
			contentStart.InsertTextInRun(block.OriginalUrl);
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler);
			base.TextChanged += new TextChangedEventHandler(this.TextChangedEventHandler2);
			int num = this.GetLength() + this.hiddenTinyUrlCount;
			if ((num < 140) && !twitterNamesDictionary.ContainsKey(block.OriginalUrl))
			{
				twitterNamesDictionary.Add(block.OriginalUrl, string.Empty);
			}
			this.ParseForFormatting();
			base.Focus();
		}

		private void tinyUrlBlock_TinyUrlChanged(object sender, EventArgs e)
		{
			TinyUrlBlock block = sender as TinyUrlBlock;
			if (!block.IsDisposed)
			{
				this.ChangeHiddenTinyUrlCount(-22);
				this.ChangeHiddenTinyUrlCount(block.TinyUrl.Length);
			}
			this.ParseForFormatting();
		}

		private void tinyUrlBlock_Unloaded(object sender, RoutedEventArgs e)
		{
			TinyUrlBlock block = sender as TinyUrlBlock;
			block.IsDisposed = true;
			block.Unloaded -= new RoutedEventHandler(this.tinyUrlBlock_Unloaded);
			if (block.IsTinyUrlUpdated)
			{
				if (block.TinyUrl.Length > 0)
				{
					this.ChangeHiddenTinyUrlCount(block.TinyUrl.Length * -1);
				}
			}
			else
			{
				this.ChangeHiddenTinyUrlCount(-22);
			}
		}

		// Properties
		public string PlainText
		{
			get
			{
				return this.GetTextOnlyString();
			}
		}

		public int TextLength
		{
			get
			{
				return (int) base.GetValue(TextLengthProperty);
			}
		}

		public Dictionary<string, string> TwitterNamesDictionary
		{
			get
			{
				return twitterNamesDictionary;
			}
		}

		// Nested Types
		private class Word
		{
			// Fields
			private readonly TextPointer _wordEnd;
			private readonly TextPointer _wordStart;

			// Methods
			public Word(TextPointer wordStart, TextPointer wordEnd)
			{
				this._wordStart = wordStart.GetPositionAtOffset(0, LogicalDirection.Forward);
				this._wordEnd = wordEnd.GetPositionAtOffset(0, LogicalDirection.Backward);
			}

			// Properties
			public TextPointer End
			{
				get
				{
					return this._wordEnd;
				}
			}

			public TextPointer Start
			{
				get
				{
					return this._wordStart;
				}
			}
		}
	}
}