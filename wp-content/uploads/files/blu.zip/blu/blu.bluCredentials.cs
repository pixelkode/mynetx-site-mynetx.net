namespace blu
{
	[Serializable]
	public class bluCredentials : CredentialsBase
	{
		// Fields
		private double applicationOpacity;
		private bool automaticallyLogin;
		private bool enableLogging;
		private double refreshIntervalInMinutes;
		private bool rememberLoginInfo;
		private bool soundedUpdates;
		private Point windowLocation;

		// Properties
		public double ApplicationOpacity
		{
			get
			{
				return this.applicationOpacity;
			}
			set
			{
				this.applicationOpacity = value;
			}
		}

		public bool AutomaticallyLogin
		{
			get
			{
				return this.automaticallyLogin;
			}
			set
			{
				this.automaticallyLogin = value;
			}
		}

		public bool EnableLogging
		{
			get
			{
				return this.enableLogging;
			}
			set
			{
				this.enableLogging = value;
			}
		}

		public double RefreshIntervalInMinutes
		{
			get
			{
				return this.refreshIntervalInMinutes;
			}
			set
			{
				this.refreshIntervalInMinutes = value;
			}
		}

		public bool RememberLoginInfo
		{
			get
			{
				return this.rememberLoginInfo;
			}
			set
			{
				this.rememberLoginInfo = value;
			}
		}

		public bool SoundedUpdates
		{
			get
			{
				return this.soundedUpdates;
			}
			set
			{
				this.soundedUpdates = value;
			}
		}

		public Point WindowLocation
		{
			get
			{
				return this.windowLocation;
			}
			set
			{
				this.windowLocation = value;
			}
		}
	}
}