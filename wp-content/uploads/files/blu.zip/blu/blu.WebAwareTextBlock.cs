namespace blu
{
	public class WebAwareTextBlock : TextBlock
	{
		// Fields
		public static readonly RoutedEvent HashtagClickEvent = EventManager.RegisterRoutedEvent("HashtagClick", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(WebAwareTextBlock));
		public static readonly RoutedEvent NameClickEvent = EventManager.RegisterRoutedEvent("NameClick", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(WebAwareTextBlock));
		public static readonly RoutedEvent ReplyNameClickEvent = EventManager.RegisterRoutedEvent("ReplyNameClick", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(WebAwareTextBlock));
		public static readonly DependencyProperty ReplyToIdProperty = DependencyProperty.Register("ReplyToId", typeof(string), typeof(WebAwareTextBlock), new FrameworkPropertyMetadata(string.Empty));
		public static readonly DependencyProperty WebAwareTextProperty = DependencyProperty.Register("WebAwareText", typeof(string), typeof(WebAwareTextBlock), new FrameworkPropertyMetadata(string.Empty, new PropertyChangedCallback(WebAwareTextBlock.OnWebAwareTextChanged)));

		// Events
		public event RoutedEventHandler HashtagClick
		{
			add
			{
				base.AddHandler(HashtagClickEvent, value);
			}
			remove
			{
				base.RemoveHandler(HashtagClickEvent, value);
			}
		}

		public event RoutedEventHandler NameClick
		{
			add
			{
				base.AddHandler(NameClickEvent, value);
			}
			remove
			{
				base.RemoveHandler(NameClickEvent, value);
			}
		}

		public event RoutedEventHandler ReplyNameClick
		{
			add
			{
				base.AddHandler(ReplyNameClickEvent, value);
			}
			remove
			{
				base.RemoveHandler(ReplyNameClickEvent, value);
			}
		}

		// Methods
		public static string EnsureProtocol(string word)
		{
			if (word.StartsWith("http", StringComparison.OrdinalIgnoreCase))
			{
				return word;
			}
			return ("http://" + word);
		}

		private static void hashtag_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (e.OriginalSource is Hyperlink)
				{
					Hyperlink originalSource = e.OriginalSource as Hyperlink;
					if (originalSource.Parent is WebAwareTextBlock)
					{
						(originalSource.Parent as WebAwareTextBlock).RaiseEvent(new RoutedEventArgs(HashtagClickEvent, originalSource));
					}
				}
			}
			catch
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("There was a problem launching the specified URL.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private static void link_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				Process.Start(((Hyperlink) sender).NavigateUri.ToString());
			}
			catch
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("There was a problem launching the specified URL.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private static void name_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (e.OriginalSource is Hyperlink)
				{
					Hyperlink originalSource = e.OriginalSource as Hyperlink;
					if (originalSource.Parent is WebAwareTextBlock)
					{
						(originalSource.Parent as WebAwareTextBlock).RaiseEvent(new RoutedEventArgs(NameClickEvent, originalSource));
					}
				}
			}
			catch
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("There was a problem launching the specified URL.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private static void OnWebAwareTextChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
		{
			string newValue = args.NewValue as string;
			WebAwareTextBlock block = obj as WebAwareTextBlock;
			if ((block != null) && !string.IsNullOrEmpty(newValue))
			{
				block.Inlines.Clear();
				foreach (string str2 in newValue.Split(new char[] { ' ' }))
				{
					if (str2.Equals("<a"))
					{
						string uriString = newValue.Substring(newValue.IndexOf("\"") + 1, (newValue.LastIndexOf("\"") - newValue.IndexOf("\"")) - 1);
						string text = newValue.Substring(newValue.IndexOf(">") + 1, (newValue.LastIndexOf("<") - newValue.IndexOf(">")) - 1);
						Hyperlink item = new Hyperlink();
						item.NavigateUri = new Uri(uriString);
						item.Inlines.Add(text);
						item.Click += new RoutedEventHandler(WebAwareTextBlock.link_Click);
						item.ToolTip = "Go see what " + text + " is all about";
						block.Inlines.Add(item);
						return;
					}
					if (bluRichTextBox.urlCheck.IsMatch(str2))
					{
						string str5 = EnsureProtocol(str2);
						try
						{
							Hyperlink hyperlink2 = new Hyperlink();
							hyperlink2.NavigateUri = new Uri(str5);
							hyperlink2.Inlines.Add(str5);
							hyperlink2.Click += new RoutedEventHandler(WebAwareTextBlock.link_Click);
							hyperlink2.ToolTip = "Open link in the default browser";
							block.Inlines.Add(hyperlink2);
						}
						catch
						{
							block.Inlines.Add(str5);
						}
					}
					else if (str2.StartsWith("@"))
					{
						string str6 = string.Empty;
						Match match = Regex.Match(str2, @"@(\w+)(?<suffix>.*)");
						if (match.Success)
						{
							str6 = match.Groups[1].Captures[0].Value;
							Hyperlink hyperlink3 = new Hyperlink();
							hyperlink3.Inlines.Add(str6);
							hyperlink3.NavigateUri = new Uri("http://twitter.com/" + str6);
							hyperlink3.ToolTip = "View @" + str6 + "'s informations";
							hyperlink3.Tag = str6;
							hyperlink3.Click += new RoutedEventHandler(WebAwareTextBlock.name_Click);
							block.Inlines.Add("@");
							block.Inlines.Add(hyperlink3);
							block.Inlines.Add(match.Groups["suffix"].Captures[0].Value);
						}
					}
					else if (str2.StartsWith("$"))
					{
						string str7 = string.Empty;
						Match match2 = Regex.Match(str2, @"\$(\w+)(?<suffix>.*)");
						if (match2.Success)
						{
							str7 = match2.Groups[1].Captures[0].Value;
							if (str7.Equals(block.ReplyToId))
							{
								Hyperlink hyperlink4 = new Hyperlink();
								hyperlink4.Inlines.Add("Tweet");
								hyperlink4.NavigateUri = new Uri("http://twitter.com/statuses/show/" + str7);
								hyperlink4.ToolTip = "View original tweet.";
								hyperlink4.Tag = str7;
								hyperlink4.Click += new RoutedEventHandler(WebAwareTextBlock.replyName_Click);
								block.Inlines.Add(hyperlink4);
								block.Inlines.Add(match2.Groups["suffix"].Captures[0].Value);
							}
							else
							{
								block.Inlines.Add(str2);
							}
						}
					}
					else if (str2.StartsWith("#"))
					{
						string str8 = string.Empty;
						Match match3 = Regex.Match(str2, @"#(\w+)(?<suffix>.*)");
						if (match3.Success)
						{
							str8 = match3.Groups[1].Captures[0].Value;
							Hyperlink hyperlink5 = new Hyperlink();
							hyperlink5.Inlines.Add(str8);
							hyperlink5.NavigateUri = new Uri("http://search.twitter.com/search?q=%23" + str8);
							hyperlink5.ToolTip = "Show statuses that include this hashtag";
							hyperlink5.Tag = str8;
							hyperlink5.Click += new RoutedEventHandler(WebAwareTextBlock.hashtag_Click);
							block.Inlines.Add("#");
							block.Inlines.Add(hyperlink5);
							block.Inlines.Add(match3.Groups["suffix"].Captures[0].Value);
						}
					}
					else
					{
						block.Inlines.Add(str2);
					}
					block.Inlines.Add(" ");
				}
			}
		}

		private static void replyName_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				if (e.OriginalSource is Hyperlink)
				{
					Hyperlink originalSource = e.OriginalSource as Hyperlink;
					if (originalSource.Parent is WebAwareTextBlock)
					{
						(originalSource.Parent as WebAwareTextBlock).RaiseEvent(new RoutedEventArgs(ReplyNameClickEvent, originalSource));
					}
				}
			}
			catch
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("There was a problem launching the specified URL.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		// Properties
		public string ReplyToId
		{
			get
			{
				return (string) base.GetValue(ReplyToIdProperty);
			}
			set
			{
				base.SetValue(ReplyToIdProperty, value);
			}
		}

		public string WebAwareText
		{
			get
			{
				return (string) base.GetValue(WebAwareTextProperty);
			}
			set
			{
				base.SetValue(WebAwareTextProperty, value);
			}
		}
	}
}