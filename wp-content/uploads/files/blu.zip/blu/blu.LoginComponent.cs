namespace blu
{
	public class LoginComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		private SoundPlayer clickyclicky = new SoundPlayer();
		private int currentKey;
		internal Grid InputElements;
		private bool isAutoLoggingIn;
		private bool isBad;
		private Random keyRandomizer;
		private Timer keyTimer;
		internal Border LayoutRoot;
		public static readonly RoutedEvent LoggedInEvent = EventManager.RegisterRoutedEvent("LoggedIn", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(LoginComponent));
		internal ImageButton LoginButton;
		internal PasswordBox PasswordTextBox;
		internal CheckBox Rememberage;
		private Stream soundStream;
		internal TextBox UsernameTextBox;

		// Events
		public event RoutedEventHandler LoggedIn
		{
			add
			{
				base.AddHandler(LoggedInEvent, value);
			}
			remove
			{
				base.RemoveHandler(LoggedInEvent, value);
			}
		}

		// Methods
		public LoginComponent()
		{
			base.Loaded += new RoutedEventHandler(this.LoginComponent_Loaded);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.LoadSoundStream();
			this.keyRandomizer = new Random(DateTime.Now.Millisecond);
			this.keyTimer = new Timer();
			this.keyTimer.Elapsed += new ElapsedEventHandler(this.keyTimer_Elapsed);
			if (App.TwitterSource == null)
			{
				App.TwitterSource = new TwitterAPIWrapper();
			}
			App.TwitterSource.add_LoginProcessed(new LoginProcessedHandler(this, (IntPtr) this.TwitterSource_LoginProcessed));
			this.InitializeComponent();
		}

		private void AnimateAutoLogin()
		{
			if (this.currentKey == App.BluCredentials.get_UserName().Length)
			{
				this.UsernameTextBox.Text = App.BluCredentials.get_UserName().Substring(0, this.currentKey);
				this.PlayKlickSound();
				this.isAutoLoggingIn = false;
				this.LoginButton_Click(null, null);
			}
			else
			{
				if (this.currentKey == 0)
				{
					this.keyTimer.Interval = this.keyRandomizer.Next(500);
					this.currentKey++;
					this.keyTimer.Start();
				}
				else
				{
					try
					{
						this.UsernameTextBox.Text = App.BluCredentials.get_UserName().Substring(0, this.currentKey - 1);
						this.PlayKlickSound();
						this.keyTimer.Interval = this.keyRandomizer.Next(20, 250);
						this.currentKey++;
						this.keyTimer.Start();
					}
					catch
					{
						this.keyTimer.Stop();
						this.UsernameTextBox.Text = App.BluCredentials.get_UserName();
						this.isBad = true;
						this.isAutoLoggingIn = false;
						this.LoginButton_Click(null, null);
					}
				}
				if (this.UsernameTextBox.Text.Length > 0)
				{
					this.UsernameTextBox.SelectionStart = this.UsernameTextBox.Text.Length;
				}
			}
		}

		private void CheckBox_Checked(object sender, RoutedEventArgs e)
		{
			App.BluCredentials.RememberLoginInfo = true;
			if ((this.UsernameTextBox.Text.Length > 0) && (this.PasswordTextBox.Password.Length > 0))
			{
				App.BluCredentials.set_UserName(this.UsernameTextBox.Text);
				App.BluCredentials.set_Password(this.PasswordTextBox.Password);
			}
		}

		private void CheckBox_Unchecked(object sender, RoutedEventArgs e)
		{
			string str;
			string str2;
			App.BluCredentials.RememberLoginInfo = false;
			App.BluCredentials.set_UserName(str = string.Empty);
			this.UsernameTextBox.Text = str;
			App.BluCredentials.set_Password(str2 = string.Empty);
			this.PasswordTextBox.Password = str2;
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at login component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		public void Hide()
		{
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/logincomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void keyTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				try
				{
					this.keyTimer.Stop();
					if (!this.isBad)
					{
						this.AnimateAutoLogin();
					}
				}
				catch (Exception exception)
				{
					(Application.Current.MainWindow as MainWindow).ShowPopup("Problem with auto login. " + exception.Message + Environment.NewLine + exception.StackTrace, PopupWindow.PopupWindowTypes.Information);
					bluHelper.WriteToLogger("Problem with auto login (keyTimer_Elapsed). " + exception.Message + Environment.NewLine + exception.StackTrace, 1);
				}
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new KeyTimerElapsedHandler(this.keyTimer_Elapsed), sender, new object[] { e });
			}
		}

		private void LoadSoundStream()
		{
			this.soundStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("blu.Resources.Sounds.blu_type_click.wav");
		}

		private void LoginButton_Click(object sender, RoutedEventArgs e)
		{
			if (!App.IsLoggingIn)
			{
				App.IsLoggingIn = true;
				if ((this.keyTimer != null) && this.keyTimer.Enabled)
				{
					this.keyTimer.Stop();
				}
				if ((((MainWindow) Application.Current.MainWindow).HasConnectivity && !this.isAutoLoggingIn) && ((this.UsernameTextBox.Text.Length > 0) && (this.PasswordTextBox.Password.Length > 0)))
				{
					this.InputElements.IsEnabled = false;
					((MainWindow) Application.Current.MainWindow).StartWorking();
					if (App.BluCredentials.RememberLoginInfo)
					{
						App.BluCredentials.set_UserName(this.UsernameTextBox.Text);
						App.BluCredentials.set_Password(this.PasswordTextBox.Password);
					}
					App.TwitterSource.set_EnableLogging(App.BluCredentials.EnableLogging);
					App.TwitterSource.set_UserName(this.UsernameTextBox.Text);
					App.TwitterSource.set_Password(this.PasswordTextBox.Password);
					App.TwitterSource.Login();
				}
			}
		}

		private void LoginComponent_Loaded(object sender, RoutedEventArgs e)
		{
			if ((App.BluCredentials.AutomaticallyLogin && (App.BluCredentials.get_UserName().Length > 0)) && (App.BluCredentials.get_Password().Length > 0))
			{
				if (App.BluCredentials.RememberLoginInfo)
				{
					this.Rememberage.IsChecked = true;
				}
				if (this.UsernameTextBox.Text.Equals(string.Empty))
				{
					this.PasswordTextBox.Password = App.BluCredentials.get_Password();
				}
				else
				{
					this.UsernameTextBox.Text = App.BluCredentials.get_UserName();
					this.PasswordTextBox.Password = App.BluCredentials.get_Password();
				}
			}
			else if (App.BluCredentials.RememberLoginInfo)
			{
				this.Rememberage.IsChecked = true;
				this.UsernameTextBox.Text = App.BluCredentials.get_UserName();
				this.PasswordTextBox.Password = App.BluCredentials.get_Password();
			}
		}

		private void PasswordTextBox_PasswordChanged(object sender, RoutedEventArgs e)
		{
			if (this.PasswordTextBox.Password.Length < 1)
			{
				this.PasswordTextBox.Tag = "Password";
			}
			else
			{
				this.PasswordTextBox.Tag = "";
			}
		}

		private void PlayKlickSound()
		{
			this.soundStream.Position = 0L;
			this.clickyclicky.Stream = null;
			this.clickyclicky.Stream = this.soundStream;
			this.clickyclicky.Play();
		}

		public void Show()
		{
			DoubleAnimation animation = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(500.0)));
			animation.Completed += delegate {
				this.UsernameTextBox.Focus();
				this.UsernameTextBox.SelectionStart = this.UsernameTextBox.Text.Length;
				this.UsernameTextBox.SelectionLength = 0;
			};
			this.UsernameTextBox.BeginAnimation(UIElement.OpacityProperty, animation);
			this.InputElements.IsEnabled = true;
		}

		public void StartAutoLogin()
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				if ((App.BluCredentials.get_UserName().Length > 0) && (App.BluCredentials.get_Password().Length > 0))
				{
					this.isAutoLoggingIn = true;
					this.AnimateAutoLogin();
				}
			}
			else
			{
				this.UsernameTextBox.Text = App.BluCredentials.get_UserName();
			}
		}

		[DebuggerNonUserCode, EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.LayoutRoot = (Border) target;
					return;

				case 2:
					this.InputElements = (Grid) target;
					return;

				case 3:
					this.UsernameTextBox = (TextBox) target;
					this.UsernameTextBox.KeyDown += new KeyEventHandler(this.TypeSound_KeyDown);
					return;

				case 4:
					this.PasswordTextBox = (PasswordBox) target;
					this.PasswordTextBox.PasswordChanged += new RoutedEventHandler(this.PasswordTextBox_PasswordChanged);
					this.PasswordTextBox.KeyDown += new KeyEventHandler(this.TypeSound_KeyDown);
					return;

				case 5:
					this.Rememberage = (CheckBox) target;
					this.Rememberage.Checked += new RoutedEventHandler(this.CheckBox_Checked);
					this.Rememberage.Unchecked += new RoutedEventHandler(this.CheckBox_Unchecked);
					return;

				case 6:
					this.LoginButton = (ImageButton) target;
					this.LoginButton.Click += new RoutedEventHandler(this.LoginButton_Click);
					return;
			}
			this._contentLoaded = true;
		}

		private void TwitterSource_LoginProcessed(object sender, LoginEventArgs e)
		{
			App.IsLoggingIn = false;
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_IsLoggedIn())
			{
				App.LoggedInUser = e.get_LoggedInUser();
				App.TwitterSource.set_EnableLogging(App.BluCredentials.EnableLogging);
				base.RaiseEvent(new RoutedEventArgs(LoggedInEvent));
			}
			else
			{
				this.InputElements.IsEnabled = true;
				(Application.Current.MainWindow as MainWindow).ShowPopup("Unable to login. " + e.get_FailReason(), PopupWindow.PopupWindowTypes.Information);
			}
		}

		private void TypeSound_KeyDown(object sender, KeyEventArgs e)
		{
			if (((e.Key != Key.Space) && (e.Key != Key.Return)) && (e.Key != Key.End))
			{
				this.PlayKlickSound();
			}
		}

		// Nested Types
		private delegate void KeyTimerElapsedHandler(object sender, ElapsedEventArgs e);
	}

