namespace blu
{
	public class TwitterDataListComponent : UserControl, IComponentConnector, IStyleConnector
	{
		// Fields
		private bool _contentLoaded;
		private TwitterAPIWrapper api;
		public static readonly DependencyProperty AtEndProperty = DependencyProperty.Register("AtEnd", typeof(bool), typeof(TwitterDataListComponent), new FrameworkPropertyMetadata(new PropertyChangedCallback(TwitterDataListComponent.OnAtEndChanged)));
		internal ImageButton BlockButton;
		public static readonly DependencyProperty CanGetMoreProperty = DependencyProperty.Register("CanGetMore", typeof(bool), typeof(TwitterDataListComponent), new FrameworkPropertyMetadata(true));
		private User currentUser;
		internal ImageButton FavoriteButton;
		internal StackPanel FavoriteContainer;
		public static readonly RoutedEvent FavoriteFriendEvent = EventManager.RegisterRoutedEvent("FavoriteFriend", RoutingStrategy.Bubble, typeof(FavoriteFriendEventHandler), typeof(TwitterDataListComponent));
		internal FlipComponent FlipOverlay;
		internal ImageButton FollowButton;
		internal StackPanel FollowContainer;
		public static readonly RoutedEvent GetMoreTwitterDataEvent = EventManager.RegisterRoutedEvent("GetMoreTwitterData", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(TwitterDataListComponent));
		internal DeferredSelectionListBox List;
		internal Grid OpacityEffectEnabler;
		private string originalTweetId;
		internal Image PrivateText;
		internal TranslateTransform PrivateTextTranslater;
		internal Grid PrivateUserInfo;
		internal Grid Rooty;
		private DeferredSelectionListBoxItem selectedItem;
		internal ImageButton SendRequestButton;
		internal TranslateTransform SendRequestButtonTranslater;
		public static readonly DependencyProperty ShowsUserInfoProperty = DependencyProperty.Register("ShowsUserInfo", typeof(bool), typeof(TwitterDataListComponent), new FrameworkPropertyMetadata(false, new PropertyChangedCallback(TwitterDataListComponent.OnShowUserInfoChanged)));
		internal Grid StatusBubble;
		internal ScaleTransform StatusBubbleScaler;
		public static readonly DependencyProperty TwitterCollectionSourceProperty = DependencyProperty.Register("TwitterCollectionSource", typeof(TwitterDataCollection), typeof(TwitterDataListComponent));
		public static readonly RoutedEvent TwitterDataCreationEvent = EventManager.RegisterRoutedEvent("TwitterDataCreation", RoutingStrategy.Bubble, typeof(TwitterDataDeletionEventHandler), typeof(TwitterDataListComponent));
		public static readonly RoutedEvent TwitterDataDeletionEvent = EventManager.RegisterRoutedEvent("TwitterDataDeletion", RoutingStrategy.Bubble, typeof(TwitterDataDeletionEventHandler), typeof(TwitterDataListComponent));
		public static readonly DependencyProperty TwitterDataTypeProperty = DependencyProperty.Register("TwitterDataType", typeof(TwitterDataTypes), typeof(TwitterDataListComponent), new FrameworkPropertyMetadata(new PropertyChangedCallback(TwitterDataListComponent.OnTwitterDataTypeChanged)));
		internal TwitterDataListComponent uc;
		private const double UIOFFSET = 40.0;
		internal ImageButton UnFavoriteButton;
		internal StackPanel UnFavoriteContainer;
		public static readonly RoutedEvent UnFavoriteFriendEvent = EventManager.RegisterRoutedEvent("UnFavoriteFriend", RoutingStrategy.Bubble, typeof(UnFavoriteFriendEventHandler), typeof(TwitterDataListComponent));
		internal ImageButton UnFollowButton;
		internal StackPanel UnFollowContainer;
		internal Grid UserActionButtons;
		private User userBeingProcessed;
		internal Grid UserInfo;
		private string userName;
		internal WebAwareTextBlock UserSiteUrl;
		public static readonly RoutedEvent UserViewEvent = EventManager.RegisterRoutedEvent("UserView", RoutingStrategy.Bubble, typeof(UserViewEventHandler), typeof(TwitterDataListComponent));
		internal ImageButton ViewUserTweets;

		// Events
		public event FavoriteFriendEventHandler FavoriteFriend
		{
			add
			{
				base.AddHandler(FavoriteFriendEvent, value);
			}
			remove
			{
				base.RemoveHandler(FavoriteFriendEvent, value);
			}
		}

		public event RoutedEventHandler GetMoreTwitterData
		{
			add
			{
				base.AddHandler(GetMoreTwitterDataEvent, value);
			}
			remove
			{
				base.RemoveHandler(GetMoreTwitterDataEvent, value);
			}
		}

		public event TwitterDataCreationEventHandler TwitterDataCreation
		{
			add
			{
				base.AddHandler(TwitterDataCreationEvent, value);
			}
			remove
			{
				base.RemoveHandler(TwitterDataCreationEvent, value);
			}
		}

		public event TwitterDataDeletionEventHandler TwitterDataDeletion
		{
			add
			{
				base.AddHandler(TwitterDataDeletionEvent, value);
			}
			remove
			{
				base.RemoveHandler(TwitterDataDeletionEvent, value);
			}
		}

		public event UnFavoriteFriendEventHandler UnFavoriteFriend
		{
			add
			{
				base.AddHandler(UnFavoriteFriendEvent, value);
			}
			remove
			{
				base.RemoveHandler(UnFavoriteFriendEvent, value);
			}
		}

		public event UserViewEventHandler UserView
		{
			add
			{
				base.AddHandler(UserViewEvent, value);
			}
			remove
			{
				base.RemoveHandler(UserViewEvent, value);
			}
		}

		// Methods
		public TwitterDataListComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
			base.DataContext = this;
			this.FlipOverlay.ParentControl = this;
		}

		[DebuggerNonUserCode]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		private void api_BlockUserProcessed(object sender, UserCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (!e.get_RequestIsGood())
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't block the user. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void api_CurrentUserTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				this.ViewUserTweets.IsHitTestVisible = false;
				DoubleAnimation animation = new DoubleAnimation(0.0, new Duration(TimeSpan.FromMilliseconds(350.0)));
				this.ViewUserTweets.BeginAnimation(UIElement.OpacityProperty, animation);
				this.TwitterCollectionSource = e.get_NewTwitterDataCollection();
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't get user's timeline: " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void api_FriendUserProcessed(object sender, UserCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				this.FollowContainer.Visibility = Visibility.Collapsed;
				this.UnFollowContainer.Visibility = Visibility.Visible;
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't friend the user. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void api_MostRecentUserTweetProcessed(object sender, TwitterDataCreatedEventArgs e)
		{
			if (e.get_RequestIsGood())
			{
				this.userBeingProcessed.set_Tweet(e.get_NewTwitterData() as Tweet);
			}
			else if (!e.get_FailureDetails().Contains("Not authorized"))
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't get user's most recent tweet. Here's why: " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
			base.RaiseEvent(new bluRoutedEventArgs(UserViewEvent, this, this.userBeingProcessed));
		}

		private void api_TestFriendshipProcessed(object sender, bluEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				if (e.get_AdditionalInfo().Equals("true"))
				{
					this.FollowContainer.Visibility = Visibility.Collapsed;
					this.UnFollowContainer.Visibility = Visibility.Visible;
				}
				else
				{
					if (this.currentUser.get_IsProtected())
					{
						this.PrivateUserInfo.DataContext = this.currentUser;
						((MainWindow) Application.Current.MainWindow).LockSequence.add_Completed(new RoutedEventHandler(this.LockSequence_Completed));
						((MainWindow) Application.Current.MainWindow).LockSequence.Start();
						this.UserInfo.Visibility = Visibility.Collapsed;
						this.PrivateUserInfo.Visibility = Visibility.Visible;
						if (((MainWindow) Application.Current.MainWindow).LockSequence.get_Images() == null)
						{
							((MainWindow) Application.Current.MainWindow).LoadLockSequence();
						}
						((Storyboard) base.FindResource("ShowLockInfo")).Begin(this);
						return;
					}
					this.FollowContainer.Visibility = Visibility.Visible;
					this.UnFollowContainer.Visibility = Visibility.Collapsed;
				}
				this.FireOffUI();
			}
		}

		private void api_UnBlockUserProcessed(object sender, UserCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (!e.get_RequestIsGood())
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't unblock the user. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void api_UnFriendUserProcessed(object sender, UserCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				this.FollowContainer.Visibility = Visibility.Visible;
				this.UnFollowContainer.Visibility = Visibility.Collapsed;
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't unfriend the user. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void api_UserInfoProcessed(object sender, UserCreatedEventArgs e)
		{
			if (e.get_RequestIsGood())
			{
				if (e.get_User().get_Tweet() == null)
				{
					this.userBeingProcessed = e.get_User();
					this.api.GetMostRecentUserTweet(e.get_User().get_Id().ToString());
				}
				else
				{
					base.RaiseEvent(new bluRoutedEventArgs(UserViewEvent, this, e.get_User()));
				}
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Couldn't get user info. Here's why: " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void BlockButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.api.BlockUser(((User) this.UserInfo.DataContext).get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't block this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at twitter datalist component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		private void Delete_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				base.RaiseEvent(new bluRoutedEventArgs(TwitterDataDeletionEvent, this, ((FrameworkElement) sender).Tag));
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't delete tweet, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void Direct_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				this.selectedItem = this.List.ItemContainerGenerator.ContainerFromItem(((FrameworkElement) sender).Tag) as DeferredSelectionListBoxItem;
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.CreateDirectMessage, ((FrameworkElement) sender).Tag);
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't direct message, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		public void DisableList()
		{
			((Storyboard) base.FindResource("ListFadeOut")).Begin(this);
			this.List.set_RespondToInput(false);
		}

		public void EnableList()
		{
			((Storyboard) base.FindResource("ListFadeIn")).Begin(this);
			this.List.set_RespondToInput(true);
		}

		private void FavoriteFriend_Click(object sender, RoutedEventArgs e)
		{
			if (!App.TwitterSource.ReachedMaxFavoriteFriendLimit() && ((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				User dataContext = this.UserInfo.DataContext as User;
				dataContext.get_Tweet().set_User(dataContext);
				base.RaiseEvent(new bluRoutedEventArgs(FavoriteFriendEvent, this, dataContext.get_Tweet()));
				this.FavoriteContainer.Visibility = Visibility.Collapsed;
				this.UnFavoriteContainer.Visibility = Visibility.Visible;
				if (this.TwitterCollectionSource != null)
				{
					foreach (Tweet tweet in this.TwitterCollectionSource)
					{
						if (tweet.get_User().get_Id() == dataContext.get_Id())
						{
							tweet.get_User().set_IsFavoriteFriend(true);
						}
					}
				}
			}
			else if (!((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't favorite this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void FireOffUI()
		{
			this.UserInfo.DataContext = this.currentUser;
			this.UserInfo.Visibility = Visibility.Visible;
			DoubleAnimation animation = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(1.0)));
			this.ViewUserTweets.BeginAnimation(UIElement.OpacityProperty, animation);
			this.ViewUserTweets.IsHitTestVisible = true;
			((Storyboard) base.FindResource("UserInfoBubbleIn")).Begin(this);
			DoubleAnimation animation2 = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(500.0)));
			animation2.BeginTime = new TimeSpan?(TimeSpan.FromMilliseconds(1000.0));
			this.UserActionButtons.BeginAnimation(UIElement.OpacityProperty, animation2);
		}

		private void FollowButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.api.FriendUser(((User) this.UserInfo.DataContext).get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't follow this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		public void HookUpAPIEvents()
		{
			this.api = new TwitterAPIWrapper(App.TwitterSource.get_UserName(), App.TwitterSource.get_Password(), App.TwitterSource.get_EnableLogging());
			this.api.add_UserInfoProcessed(new UserInfoProcessedHandler(this, (IntPtr) this.api_UserInfoProcessed));
			this.api.add_SingleTweetProcessed(new SingleTweetProcessedHandler(this, (IntPtr) this.TwitterSource_SingleTweetProcessed));
			this.api.add_MostRecentUserTweetProcessed(new MostRecentUserTweetProcessedHandler(this, (IntPtr) this.api_MostRecentUserTweetProcessed));
			this.api.add_CurrentUserTimelineProcessed(new CurrentUserTimelineProcessedHandler(this, (IntPtr) this.api_CurrentUserTimelineProcessed));
			this.api.add_BlockUserProcessed(new BlockUserProcessedHandler(this, (IntPtr) this.api_BlockUserProcessed));
			this.api.add_UnBlockUserProcessed(new UnBlockUserProcessedHandler(this, (IntPtr) this.api_UnBlockUserProcessed));
			this.api.add_FriendUserProcessed(new FriendUserProcessedHandler(this, (IntPtr) this.api_FriendUserProcessed));
			this.api.add_UnFriendUserProcessed(new UnFriendUserProcessedHandler(this, (IntPtr) this.api_UnFriendUserProcessed));
			this.api.add_TestFriendshipProcessed(new TestFriendshipProcessedHandler(this, (IntPtr) this.api_TestFriendshipProcessed));
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/twitterdatalistcomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		public void InitUserView(User user)
		{
			this.UserSiteUrl.Text = "";
			this.currentUser = user;
			if (this.currentUser.get_Id() == App.LoggedInUser.get_Id())
			{
				this.FollowButton.IsEnabled = this.UnFollowButton.IsEnabled = this.BlockButton.IsEnabled = false;
			}
			else
			{
				this.FollowButton.IsEnabled = this.UnFollowButton.IsEnabled = this.BlockButton.IsEnabled = true;
			}
			if (App.TwitterSource.IsAFavoriteFriend(this.currentUser.get_ScreenName()))
			{
				this.FavoriteContainer.Visibility = Visibility.Collapsed;
				this.UnFavoriteContainer.Visibility = Visibility.Visible;
			}
			else
			{
				this.FavoriteContainer.Visibility = Visibility.Visible;
				this.UnFavoriteContainer.Visibility = Visibility.Collapsed;
			}
			this.TwitterCollectionSource = null;
			this.UserInfo.Visibility = Visibility.Collapsed;
			this.PrivateUserInfo.Visibility = Visibility.Collapsed;
			((MainWindow) Application.Current.MainWindow).StartWorking();
			if (App.LoggedInUser.get_Id() != user.get_Id())
			{
				this.api.TestFriendship(App.LoggedInUser.get_Id().ToString(), user.get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).StopWorking();
				this.FollowContainer.Visibility = Visibility.Collapsed;
				this.UnFollowContainer.Visibility = Visibility.Visible;
				this.FireOffUI();
			}
		}

		private void LockSequence_Completed(object sender, RoutedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).LockSequence.set_InactiveFrame(15);
			((MainWindow) Application.Current.MainWindow).LockSequence.set_HiddenWhenInactive(false);
			((MainWindow) Application.Current.MainWindow).LockSequence.remove_Completed(new RoutedEventHandler(this.LockSequence_Completed));
		}

		private void MoreButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				base.RaiseEvent(new RoutedEventArgs(GetMoreTwitterDataEvent));
			}
		}

		private static void OnAtEndChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			TwitterDataListComponent component = d as TwitterDataListComponent;
			if ((((component != null) && (component.TwitterCollectionSource != null)) && ((component.TwitterCollectionSource.Count >= 20) && component.CanGetMore)) && ((bool) e.NewValue))
			{
				component.RaiseEvent(new RoutedEventArgs(GetMoreTwitterDataEvent));
			}
		}

		private static void OnShowUserInfoChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			TwitterDataListComponent component = d as TwitterDataListComponent;
			if (component != null)
			{
				if ((bool) e.NewValue)
				{
					component.UserInfo.Visibility = Visibility.Visible;
					component.PrivateUserInfo.Visibility = Visibility.Collapsed;
					component.List.set_AutoScrollBy(1);
				}
				else
				{
					component.UserInfo.Visibility = Visibility.Collapsed;
					component.PrivateUserInfo.Visibility = Visibility.Visible;
					component.ViewUserTweets.IsHitTestVisible = false;
					component.ViewUserTweets.Opacity = 0.0;
					component.List.set_AutoScrollBy(4);
				}
			}
		}

		private static void OnTwitterDataTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			TwitterDataListComponent component = d as TwitterDataListComponent;
			if (component != null)
			{
				switch (((TwitterDataTypes) e.NewValue))
				{
					case TwitterDataTypes.DirectMessage:
						component.List.ItemTemplate = component.FindResource("MessageDT") as DataTemplate;
						return;
				}
				component.List.ItemTemplate = component.FindResource("TweetDT") as DataTemplate;
			}
		}

		public void RaiseCreateEvent(TwitterData data)
		{
			base.RaiseEvent(new bluRoutedEventArgs(TwitterDataCreationEvent, this, data));
		}

		public void RaiseDeleteEvent(TwitterData data)
		{
			base.RaiseEvent(new bluRoutedEventArgs(TwitterDataDeletionEvent, this, data));
		}

		private void RelativeTime_MouseUp(object sender, MouseButtonEventArgs e)
		{
			ContentControl control = sender as ContentControl;
			if (control != null)
			{
				Tweet tag = control.Tag as Tweet;
				if (tag != null)
				{
					Clipboard.SetText("http://twitter.com/" + tag.get_User().get_ScreenName() + "/status/" + tag.get_Id().ToString());
				}
			}
		}

		private void Reply_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				this.selectedItem = this.List.ItemContainerGenerator.ContainerFromItem(((FrameworkElement) sender).Tag) as DeferredSelectionListBoxItem;
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.CreateReply, ((FrameworkElement) sender).Tag);
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't reply, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void Retweet_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				this.selectedItem = this.List.ItemContainerGenerator.ContainerFromItem(((FrameworkElement) sender).Tag) as DeferredSelectionListBoxItem;
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.CreateRetweet, ((FrameworkElement) sender).Tag);
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't retweet, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void SendRequestButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.api.FriendUser(((User) this.PrivateUserInfo.DataContext).get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't follow this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		[DebuggerNonUserCode, EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.uc = (TwitterDataListComponent) target;
					return;

				case 14:
					this.Rooty = (Grid) target;
					return;

				case 15:
					this.PrivateUserInfo = (Grid) target;
					return;

				case 0x10:
					this.PrivateText = (Image) target;
					return;

				case 0x11:
					this.PrivateTextTranslater = (TranslateTransform) target;
					return;

				case 0x12:
					this.SendRequestButton = (ImageButton) target;
					this.SendRequestButton.Click += new RoutedEventHandler(this.SendRequestButton_Click);
					return;

				case 0x13:
					this.SendRequestButtonTranslater = (TranslateTransform) target;
					return;

				case 20:
					this.OpacityEffectEnabler = (Grid) target;
					return;

				case 0x15:
					this.List = (DeferredSelectionListBox) target;
					return;

				case 0x16:
					this.FlipOverlay = (FlipComponent) target;
					return;

				case 0x17:
					this.UserInfo = (Grid) target;
					return;

				case 0x18:
					this.UserSiteUrl = (WebAwareTextBlock) target;
					return;

				case 0x19:
					this.StatusBubble = (Grid) target;
					return;

				case 0x1a:
					this.StatusBubbleScaler = (ScaleTransform) target;
					return;

				case 0x1b:
					this.UserActionButtons = (Grid) target;
					return;

				case 0x1c:
					this.FollowContainer = (StackPanel) target;
					return;

				case 0x1d:
					this.FollowButton = (ImageButton) target;
					this.FollowButton.Click += new RoutedEventHandler(this.FollowButton_Click);
					return;

				case 30:
					this.UnFollowContainer = (StackPanel) target;
					return;

				case 0x1f:
					this.UnFollowButton = (ImageButton) target;
					this.UnFollowButton.Click += new RoutedEventHandler(this.UnFollowButton_Click);
					return;

				case 0x20:
					this.FavoriteContainer = (StackPanel) target;
					return;

				case 0x21:
					this.FavoriteButton = (ImageButton) target;
					this.FavoriteButton.Click += new RoutedEventHandler(this.FavoriteFriend_Click);
					return;

				case 0x22:
					this.UnFavoriteContainer = (StackPanel) target;
					return;

				case 0x23:
					this.UnFavoriteButton = (ImageButton) target;
					this.UnFavoriteButton.Click += new RoutedEventHandler(this.UnFavoriteFriend_Click);
					return;

				case 0x24:
					this.BlockButton = (ImageButton) target;
					this.BlockButton.Click += new RoutedEventHandler(this.BlockButton_Click);
					return;

				case 0x25:
					this.ViewUserTweets = (ImageButton) target;
					this.ViewUserTweets.Click += new RoutedEventHandler(this.ViewUserTweets_Click);
					return;
			}
			this._contentLoaded = true;
		}

		[DebuggerNonUserCode, EditorBrowsable(EditorBrowsableState.Never)]
		void IStyleConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 2:
					((Grid) target).MouseEnter += new MouseEventHandler(this.TweetDTRootGrid_MouseEnter);
					((Grid) target).MouseLeave += new MouseEventHandler(this.TweetDTRootGrid_MouseLeave);
					return;

				case 3:
					((ImageButton) target).Click += new RoutedEventHandler(this.Reply_Click);
					return;

				case 4:
					((ImageButton) target).Click += new RoutedEventHandler(this.Direct_Click);
					return;

				case 5:
					((ImageButton) target).Click += new RoutedEventHandler(this.Delete_Click);
					return;

				case 6:
					((Grid) target).MouseEnter += new MouseEventHandler(this.TweetDTRootGrid_MouseEnter);
					((Grid) target).MouseLeave += new MouseEventHandler(this.TweetDTRootGrid_MouseLeave);
					return;

				case 7:
					((ImageButton) target).Click += new RoutedEventHandler(this.ViewReplyButton_Click);
					return;

				case 8:
					((ContentControl) target).MouseUp += new MouseButtonEventHandler(this.RelativeTime_MouseUp);
					return;

				case 9:
					((Grid) target).MouseEnter += new MouseEventHandler(this.TweetDTUserImageGrid_MouseEnter);
					((Grid) target).MouseLeave += new MouseEventHandler(this.TweetDTUserImageGrid_MouseLeave);
					((Grid) target).MouseUp += new MouseButtonEventHandler(this.TweetDTUserImageGrid_MouseLeftButtonUp);
					return;

				case 10:
					((ImageButton) target).Click += new RoutedEventHandler(this.Reply_Click);
					return;

				case 11:
					((ImageButton) target).Click += new RoutedEventHandler(this.Direct_Click);
					return;

				case 12:
					((ImageButton) target).Click += new RoutedEventHandler(this.Retweet_Click);
					return;

				case 13:
					((ImageButton) target).Click += new RoutedEventHandler(this.Delete_Click);
					return;
			}
		}

		private void TweetDTRootGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((Storyboard) base.FindResource("TweetDTButtonOverlayInAnimator")).Begin(sender as FrameworkElement);
			}
		}

		private void TweetDTRootGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			((Storyboard) base.FindResource("TweetDTButtonOverlayOutAnimator")).Begin(sender as FrameworkElement);
		}

		private void TweetDTUserImageGrid_MouseEnter(object sender, MouseEventArgs e)
		{
			if (!this.ShowsUserInfo && ((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((Storyboard) base.FindResource("TweetDTUserImageGridInAnimator")).Begin(sender as FrameworkElement);
			}
		}

		private void TweetDTUserImageGrid_MouseLeave(object sender, MouseEventArgs e)
		{
			if (!this.ShowsUserInfo)
			{
				((Storyboard) base.FindResource("TweetDTUserImageGridOutAnimator")).Begin(sender as FrameworkElement);
			}
		}

		private void TweetDTUserImageGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			if (!this.ShowsUserInfo && ((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				Grid grid = sender as Grid;
				this.api.GetUser(((Tweet) grid.Tag).get_User().get_Id().ToString());
			}
			else if (!((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't view profile, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_SingleTweetProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).StopWorking();
			if (e.get_RequestIsGood())
			{
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.ViewReply, e.get_NewTwitterDataCollection()[0]);
			}
			else if (e.get_FailureDetails().Contains("No status found"))
			{
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.ViewReplyNotFound, null);
			}
			else
			{
				this.FlipOverlay.FlipOver(this.selectedItem, FlipComponent.FlipContentTypes.ViewReplyPrivate, null);
			}
		}

		private void UnFavoriteFriend_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				User dataContext = this.UserInfo.DataContext as User;
				dataContext.get_Tweet().set_User(dataContext);
				base.RaiseEvent(new bluRoutedEventArgs(UnFavoriteFriendEvent, this, dataContext.get_Tweet()));
				this.FavoriteContainer.Visibility = Visibility.Visible;
				this.UnFavoriteContainer.Visibility = Visibility.Collapsed;
				if (this.TwitterCollectionSource != null)
				{
					foreach (Tweet tweet in this.TwitterCollectionSource)
					{
						if (tweet.get_User().get_Id() == dataContext.get_Id())
						{
							tweet.get_User().set_IsFavoriteFriend(false);
						}
					}
				}
			}
			else if (!((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't unfavorite this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void UnFollowButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.api.UnFriendUser(((User) this.UserInfo.DataContext).get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't unfollow this person, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		public void UninitUserView()
		{
			((Storyboard) base.FindResource("HideLockInfo")).Begin(this);
			((MainWindow) Application.Current.MainWindow).LockSequence.set_InactiveFrame(0);
			((MainWindow) Application.Current.MainWindow).LockSequence.set_HiddenWhenInactive(true);
			((Storyboard) base.FindResource("UserInfoBubbleOut")).Begin(this);
		}

		private void ViewReplyButton_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.selectedItem = this.List.ItemContainerGenerator.ContainerFromItem(((FrameworkElement) sender).Tag) as DeferredSelectionListBoxItem;
				this.originalTweetId = ((Tweet) ((FrameworkElement) sender).Tag).get_ReplyToStatusId().ToString();
				this.api.GetSingleTweet(this.originalTweetId);
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't view reply, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void ViewUserTweets_Click(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).StartWorking();
				this.api.GetUserTimeline(((User) this.UserInfo.DataContext).get_Id().ToString());
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't view tweets, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void WebAwareTextBlock_NameClick(object sender, RoutedEventArgs e)
		{
			if (((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				Hyperlink originalSource = e.OriginalSource as Hyperlink;
				if (originalSource != null)
				{
					DoubleAnimation animation = new DoubleAnimation(0.0, new Duration(TimeSpan.FromMilliseconds(1.0)));
					this.StatusBubble.BeginAnimation(UIElement.OpacityProperty, animation);
					this.userName = originalSource.Tag.ToString();
					((MainWindow) Application.Current.MainWindow).StartWorking();
					this.api.GetUser(this.userName);
				}
			}
			else
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't view profile, there's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
			e.Handled = true;
		}

		// Properties
		public bool AtEnd
		{
			get
			{
				return (bool) base.GetValue(AtEndProperty);
			}
			set
			{
				base.SetValue(AtEndProperty, value);
			}
		}

		public bool CanGetMore
		{
			get
			{
				return (bool) base.GetValue(CanGetMoreProperty);
			}
			set
			{
				base.SetValue(CanGetMoreProperty, value);
			}
		}

		public bool ShowsUserInfo
		{
			get
			{
				return (bool) base.GetValue(ShowsUserInfoProperty);
			}
			set
			{
				base.SetValue(ShowsUserInfoProperty, value);
			}
		}

		public TwitterDataCollection TwitterCollectionSource
		{
			get
			{
				return (TwitterDataCollection) base.GetValue(TwitterCollectionSourceProperty);
			}
			set
			{
				base.SetValue(TwitterCollectionSourceProperty, value);
			}
		}

		public TwitterDataTypes TwitterDataType
		{
			get
			{
				return (TwitterDataTypes) base.GetValue(TwitterDataTypeProperty);
			}
			set
			{
				base.SetValue(TwitterDataTypeProperty, value);
			}
		}

		// Nested Types
		public delegate void FavoriteFriendEventHandler(object sender, bluRoutedEventArgs e);

		public delegate void TwitterDataCreationEventHandler(object sender, bluRoutedEventArgs e);

		public delegate void TwitterDataDeletionEventHandler(object sender, bluRoutedEventArgs e);

		public enum TwitterDataTypes
		{
			StandardTweet,
			FavoriteFriendTweet,
			DirectMessage
		}

		public delegate void UnFavoriteFriendEventHandler(object sender, bluRoutedEventArgs e);

		public delegate void UserViewEventHandler(object sender, bluRoutedEventArgs e);
	}
}