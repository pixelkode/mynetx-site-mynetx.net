namespace blu
{
	public class TinyUrlBlock : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal ImageButton action;
		internal Image actionImageExpand;
		internal Image actionImageStop;
		private bool isDisposed;
		private bool isTinyUrlUpdated;
		private string originalUrl;
		internal TextBlock text;
		private string tinyUrl;

		// Events
		public event EventHandler RemoveTinyUrl;

		public event EventHandler TinyUrlChanged;

		// Methods
		public TinyUrlBlock(string url)
		{
			RoutedEventHandler handler = null;
			this.originalUrl = string.Empty;
			this.tinyUrl = string.Empty;
			this.originalUrl = url;
			this.InitializeComponent();
			if (handler == null)
			{
				handler = delegate {
					this.OnRemoveTinyUrl();
				};
			}
			this.action.Click += handler;
			App.TwitterSource.add_TinyUrlCreated(new TinyUrlCreatedHandler(this, (IntPtr) this.TwitterSource_TinyUrlCreated));
			App.TwitterSource.CreateTinyUrl(url);
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/tinyurlblock.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void OnRemoveTinyUrl()
		{
			if (this.RemoveTinyUrl != null)
			{
				this.RemoveTinyUrl(this, EventArgs.Empty);
			}
		}

		private void OnTinyUrlChanged()
		{
			if (this.TinyUrlChanged != null)
			{
				this.TinyUrlChanged(this, EventArgs.Empty);
			}
		}

		[DebuggerNonUserCode, EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.text = (TextBlock) target;
					return;

				case 2:
					this.action = (ImageButton) target;
					return;

				case 3:
					this.actionImageStop = (Image) target;
					return;

				case 4:
					this.actionImageExpand = (Image) target;
					return;
			}
			this._contentLoaded = true;
		}

		private void TwitterSource_TinyUrlCreated(object sender, TinyUrlEventArgs e)
		{
			if (e.get_OriginalUrl() == this.OriginalUrl)
			{
				App.TwitterSource.remove_TinyUrlCreated(new TinyUrlCreatedHandler(this, (IntPtr) this.TwitterSource_TinyUrlCreated));
				if (e.get_RequestIsGood())
				{
					this.tinyUrl = e.get_TinyUrl();
					this.text.Text = e.get_TinyUrl();
					this.actionImageStop.Visibility = Visibility.Collapsed;
					this.actionImageExpand.Visibility = Visibility.Visible;
					this.isTinyUrlUpdated = true;
					this.OnTinyUrlChanged();
				}
				else
				{
					this.OnRemoveTinyUrl();
				}
			}
		}

		// Properties
		public bool IsDisposed
		{
			get
			{
				return this.isDisposed;
			}
			set
			{
				this.isDisposed = value;
			}
		}

		public bool IsTinyUrlUpdated
		{
			get
			{
				return this.isTinyUrlUpdated;
			}
		}

		public string OriginalUrl
		{
			get
			{
				return this.originalUrl;
			}
		}

		public string TinyUrl
		{
			get
			{
				return this.tinyUrl;
			}
		}
	}
}