namespace blu
{
	public class MainWindow : Window, INotifyPropertyChanged, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal Image AppBackground;
		internal Image AppBottom;
		public static readonly DependencyProperty ApplicationOpacityProperty = DependencyProperty.Register("ApplicationOpacity", typeof(double), typeof(MainWindow), new FrameworkPropertyMetadata(0.0, new PropertyChangedCallback(MainWindow.OnApplicationOpacityChanged)));
		internal Image AppTop;
		internal ImageSequence AppWindowSequence;
		private Assembly assembly;
		private bool bluLogoPlaying = true;
		internal ImageSequence bluSequence;
		internal ImageButton CheckTwitterDown;
		private bool componentIsFlipped;
		internal Border ContentRoot;
		private bool couldntStartUp = true;
		internal ScaleTransform CreateScaler;
		internal ImageButton CreateTweet;
		private int currentDirectMessagePage = 2;
		private int currentFriendTimelinePage = 2;
		private int currentRepliesTimelinePage = 2;
		public static readonly DependencyProperty CurrentTimelineProperty = DependencyProperty.Register("CurrentTimeline", typeof(Timelines), typeof(MainWindow));
		private string currentUserId;
		private int currentUserViewPage = 2;
		internal TwitterDataListComponent DirectMessageList;
		internal ContentControl DirectText;
		internal TranslateTransform DirectTextT;
		internal Image DoneWorkingGlow;
		internal Thumb Dragger;
		internal ImageButton Exit;
		internal TwitterDataListComponent FavoriteFriendList;
		internal CountBubbleComponent FavoritesNewCount;
		internal ScaleTransform FavoritesScaler;
		internal ContentControl FavoritesText;
		internal TranslateTransform FavoritesTextT;
		internal Border FirstFiller;
		private const int FLAPHIGHRANGE = 0x2bf20;
		private const int FLAPLOWRANGE = 0x1d4c0;
		private Random flapRandomizer;
		private Timer flapTimer;
		internal TwitterDataListComponent FriendList;
		internal CountBubbleComponent FriendsNewCount;
		internal ImageButton GoToFavorites;
		internal ImageButton GoToHome;
		internal ImageButton GoToMessages;
		internal ImageButton GoToReplies;
		public static readonly DependencyProperty HasConnectivityProperty = DependencyProperty.Register("HasConnectivity", typeof(bool), typeof(MainWindow), new FrameworkPropertyMetadata(true, new PropertyChangedCallback(MainWindow.OnHasConnectivityChanged)));
		private bool hasStartedUp;
		internal ScaleTransform HomeScaler;
		internal ContentControl HomeText;
		internal TranslateTransform HomeTextT;
		private SoundPlayer intro = new SoundPlayer();
		private bool isRunning;
		private string lastErrorMessage = string.Empty;
		internal ImageSequence LockSequence;
		internal LoginComponent Loginner;
		internal ScaleTransform LogoIconScaler;
		internal Image LogoTitle;
		internal ScaleTransform LogoTitleScaler;
		internal MainWindow MainWin;
		internal CountBubbleComponent MessagesNewCount;
		internal ScaleTransform MessagesScaler;
		internal ImageButton Minimize;
		internal Grid NavigationContainer;
		private Timer newCountTimer;
		private int newFavoritesCountBuffer;
		public static readonly DependencyProperty NewFavoritesCountProperty = DependencyProperty.Register("NewFavoritesCount", typeof(int), typeof(MainWindow), new FrameworkPropertyMetadata(0));
		private int newMessagesCountBuffer;
		public static readonly DependencyProperty NewMessagesCountProperty = DependencyProperty.Register("NewMessagesCount", typeof(int), typeof(MainWindow), new FrameworkPropertyMetadata(0));
		private int newRepliesCountBuffer;
		public static readonly DependencyProperty NewRepliesCountProperty = DependencyProperty.Register("NewRepliesCount", typeof(int), typeof(MainWindow), new FrameworkPropertyMetadata(0));
		private int newTweetsCountBuffer;
		public static readonly DependencyProperty NewTweetsCountProperty = DependencyProperty.Register("NewTweetsCount", typeof(int), typeof(MainWindow), new FrameworkPropertyMetadata(0));
		internal ImageSequence NoConnectivityBird;
		internal Grid NoConnectivityWrapper;
		internal Grid NoFavoritesMessage;
		internal Grid NoMessagesMessage;
		internal Grid NoRepliesMessage;
		private Stream openingStream;
		internal ImageSequence RandomLogoIconFlapping;
		internal ScaleTransform RefreshScaler;
		internal ContentControl RefreshText;
		internal TranslateTransform RefreshTextT;
		internal ImageButton RefreshTweets;
		internal CountBubbleComponent RepliesNewCount;
		internal ScaleTransform RepliesScaler;
		internal ContentControl RepliesText;
		internal TranslateTransform RepliesTextT;
		internal TwitterDataListComponent ReplyList;
		internal Grid Rooty;
		internal Border SecondFiller;
		internal ImageButton Settings;
		internal SettingsComponent SettingsPopup;
		private bool shuttingDown;
		private SoundPlayer slidein = new SoundPlayer();
		private Stream slideInStream;
		private bool startingUp = true;
		private Timer startUpPause;
		internal CreateTweetComponent TwitterDataCreator;
		internal Image TwitterDownBird;
		internal ImageSequence TwitterDownWhales;
		public static readonly DependencyProperty TwitterRefreshIntervalProperty = DependencyProperty.Register("TwitterRefreshInterval", typeof(double), typeof(MainWindow), new FrameworkPropertyMetadata(0.0, new PropertyChangedCallback(MainWindow.OnTwitterRefreshIntervalChanged)));
		internal DeferredSelectionListBox UIList;
		internal Grid UIListEffectEnabler;
		internal ContentControl UpdateText;
		internal TranslateTransform UpdateTextT;
		private readonly Timer updateTimer;
		internal TwitterDataListComponent UserViewer;
		internal Grid WindowControlContainer;
		internal TranslateTransform WindowControlTranslater;
		internal ImageSequence WorkingSequence;

		// Events
		public event PropertyChangedEventHandler PropertyChanged;

		// Methods
		public MainWindow()
		{
			this.LoadSounds();
			this.SetLocation();
			this.InitializeComponent();
			this.HasConnectivity = bluHelper.HasConnectivity();
			base.DataContext = this;
			this.LoadImageSequences();
			base.Closed += new EventHandler(this.MainWindow_Closed);
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			App.TwitterSource.add_FailWhale(new FailWhaleHandler(this, (IntPtr) this.TwitterSource_FailWhale));
			App.TwitterSource.add_TestTwitterProcessed(new TestTwitterProcessedHandler(this, (IntPtr) this.TwitterSource_TestTwitterProcessed));
			NetworkChange.NetworkAvailabilityChanged += new NetworkAvailabilityChangedEventHandler(this.NetworkChange_NetworkAvailabilityChanged);
			SystemEvents.PowerModeChanged += new PowerModeChangedEventHandler(this.SystemEvents_PowerModeChanged);
			this.newCountTimer = new Timer(1500.0);
			this.newCountTimer.Elapsed += new ElapsedEventHandler(this.newCountTimer_Elapsed);
			this.SetUpFlapTimer();
			this.updateTimer = new Timer();
			this.updateTimer.Elapsed += new ElapsedEventHandler(this.updateTimer_Elapsed);
			this.TwitterRefreshInterval = App.BluCredentials.RefreshIntervalInMinutes;
			this.PauseStartup();
		}

		[DebuggerNonUserCode]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		private void AnimateApplicationOpacity()
		{
			DoubleAnimation animation = new DoubleAnimation(this.ApplicationOpacity * 0.01, new Duration(TimeSpan.FromMilliseconds(300.0)));
			this.AppBackground.BeginAnimation(UIElement.OpacityProperty, animation);
		}

		private void AppWindowSequence_Completed(object sender, RoutedEventArgs e)
		{
			if (this.shuttingDown)
			{
				App.BluCredentials.WindowLocation = new Point(base.Left, base.Top);
				try
				{
					App.BluCredentials.Encrypt();
					CredentialsHelper.SerializeObject(App.BluCredentials, App.CredentialsObjectPath);
				}
				catch (Exception exception)
				{
					bluHelper.WriteToLogger("Unable to save credentials. " + exception.Message + Environment.NewLine + exception.StackTrace, 1);
				}
				Application.Current.Shutdown();
			}
		}

		private void AppWindowSequence_FrameChanged(object sender, RoutedEventArgs e)
		{
			if (((ImageSequence) sender).get_Frame() == 1)
			{
				((ImageSequence) sender).set_InactiveFrame(7);
			}
			if (((ImageSequence) sender).get_Frame() == 6)
			{
				this.bluSequence.Start();
			}
		}

		private void AppWindowSequence_Ready(object sender, RoutedEventArgs e)
		{
			this.PlayOpening();
		}

		private void bluSequence_Completed(object sender, RoutedEventArgs e)
		{
			this.bluLogoPlaying = false;
			if (!this.HasConnectivity)
			{
				this.NoConnectivityWrapper.Visibility = Visibility.Visible;
				((Storyboard) base.FindResource("ShowNoConnectivity")).Begin(this);
			}
			this.flapTimer.Start();
		}

		private void bluSequence_FrameChanged(object sender, RoutedEventArgs e)
		{
			if (((ImageSequence) sender).get_Frame() == 0x34)
			{
				this.ApplicationOpacity = App.BluCredentials.ApplicationOpacity;
				((Storyboard) base.FindResource("UIStartupAnimator")).Begin(this);
			}
		}

		private void bluSequence_Ready(object sender, RoutedEventArgs e)
		{
		}

		private void CheckTwitterDown_Click(object sender, RoutedEventArgs e)
		{
			if (App.TwitterSource != null)
			{
				App.TwitterSource.TestTwitter();
			}
		}

		private void CreateTweet_Click(object sender, RoutedEventArgs e)
		{
			if ((this.isRunning && this.HasConnectivity) && !this.ComponentIsFlipped)
			{
				if (this.TwitterDataCreator.IsVisible)
				{
					this.TwitterDataCreator.Hide();
				}
				else
				{
					this.TwitterDataCreator.Show();
				}
			}
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			if (e.IsTerminating)
			{
				this.ShowPopup("blu has encountered an error that it doesn't know how to handle and must exit. If logging has been turned on, more details are probably in that file. See ya!", PopupWindow.PopupWindowTypes.Error);
				bluHelper.WriteToLogger("Unhandled dispatcher exception at window level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
				if (exceptionObject.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				}
				Application.Current.Shutdown();
			}
			else
			{
				this.ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
				bluHelper.WriteToLogger("Unhandled dispatcher exception at window level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
				if (exceptionObject.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
					if (exceptionObject.InnerException.InnerException != null)
					{
						bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
					}
				}
			}
		}

		private void DirectMessageList_GetMoreTwitterData(object sender, RoutedEventArgs e)
		{
			this.StartWorking();
			App.TwitterSource.GetDirectMessages(this.currentDirectMessagePage);
			this.currentDirectMessagePage++;
		}

		private void Dragger_DragDelta(object sender, DragDeltaEventArgs e)
		{
			base.Left += e.HorizontalChange;
			base.Top += e.VerticalChange;
		}

		private void Exit_Click(object sender, RoutedEventArgs e)
		{
			if (!this.shuttingDown)
			{
				this.shuttingDown = true;
				((Storyboard) base.FindResource("UIExitAnimator")).Begin(this);
			}
		}

		private void FavoritesNewCount_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.NewFavoritesCount = this.newFavoritesCountBuffer = 0;
		}

		private void flapTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.flapTimer.Stop();
				this.RandomLogoIconFlapping.Start();
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new FlapTimerElapsedHandler(this.flapTimer_Elapsed), sender, new object[] { e });
			}
		}

		private void FriendList_GetMoreTwitterData(object sender, RoutedEventArgs e)
		{
			this.StartWorking();
			App.TwitterSource.GetFriendTimeline(this.currentFriendTimelinePage);
			this.currentFriendTimelinePage++;
		}

		private void FriendsNewCount_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.NewTweetsCount = this.newTweetsCountBuffer = 0;
		}

		private void GoToFavorites_Click(object sender, RoutedEventArgs e)
		{
			this.CurrentTimeline = Timelines.FavoriteFriends;
			if (((this.UIList.get_SelectedItem() == this.DirectMessageList) && (this.DirectMessageList.TwitterCollectionSource != null)) && (this.DirectMessageList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoMessagesMessage")).Begin(this);
			}
			if ((this.FavoriteFriendList.TwitterCollectionSource != null) && (this.FavoriteFriendList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("ShowNoFavoritesMessage")).Begin(this);
			}
			if ((this.ReplyList.TwitterCollectionSource != null) && (this.ReplyList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoRepliesMessage")).Begin(this);
			}
			this.NewFavoritesCount = 0;
			if (this.UIList.get_SelectedItem() == this.FavoriteFriendList)
			{
				this.FavoriteFriendList.List.ScrollToBegin();
			}
			else
			{
				if (this.UIList.get_SelectedItem() == this.UserViewer)
				{
					this.UserViewer.UninitUserView();
				}
				this.UIList.ScrollToItem(this.FavoriteFriendList);
				this.UIList.set_SelectedItem(this.FavoriteFriendList);
			}
		}

		private void GoToHome_Click(object sender, RoutedEventArgs e)
		{
			this.CurrentTimeline = Timelines.Friends;
			if (((this.UIList.get_SelectedItem() == this.FavoriteFriendList) && (this.FavoriteFriendList.TwitterCollectionSource != null)) && (this.FavoriteFriendList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoFavoritesMessage")).Begin(this);
			}
			else if (((this.UIList.get_SelectedItem() == this.DirectMessageList) && (this.DirectMessageList.TwitterCollectionSource != null)) && (this.DirectMessageList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoMessagesMessage")).Begin(this);
			}
			if ((this.ReplyList.TwitterCollectionSource != null) && (this.ReplyList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoRepliesMessage")).Begin(this);
			}
			this.NewTweetsCount = 0;
			if (this.UIList.get_SelectedItem() == this.FriendList)
			{
				this.FriendList.List.ScrollToBegin();
			}
			else
			{
				if (this.UIList.get_SelectedItem() == this.UserViewer)
				{
					this.UserViewer.UninitUserView();
				}
				this.UIList.ScrollToItem(this.FriendList);
				this.UIList.set_SelectedItem(this.FriendList);
			}
		}

		private void GoToMessages_Click(object sender, RoutedEventArgs e)
		{
			this.CurrentTimeline = Timelines.DirectMessages;
			if (((this.UIList.get_SelectedItem() == this.FavoriteFriendList) && (this.FavoriteFriendList.TwitterCollectionSource != null)) && (this.FavoriteFriendList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoFavoritesMessage")).Begin(this);
			}
			if ((this.DirectMessageList.TwitterCollectionSource != null) && (this.DirectMessageList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("ShowNoMessagesMessage")).Begin(this);
			}
			if ((this.ReplyList.TwitterCollectionSource != null) && (this.ReplyList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoRepliesMessage")).Begin(this);
			}
			this.NewMessagesCount = 0;
			if (this.UIList.get_SelectedItem() == this.DirectMessageList)
			{
				this.DirectMessageList.List.ScrollToBegin();
			}
			else
			{
				if (this.UIList.get_SelectedItem() == this.UserViewer)
				{
					this.UserViewer.UninitUserView();
				}
				this.UIList.ScrollToItem(this.DirectMessageList);
				this.UIList.set_SelectedItem(this.DirectMessageList);
			}
		}

		private void GoToReplies_Click(object sender, RoutedEventArgs e)
		{
			this.CurrentTimeline = Timelines.Replies;
			if (((this.UIList.get_SelectedItem() == this.FavoriteFriendList) && (this.FavoriteFriendList.TwitterCollectionSource != null)) && (this.FavoriteFriendList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoFavoritesMessage")).Begin(this);
			}
			if ((this.DirectMessageList.TwitterCollectionSource != null) && (this.DirectMessageList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoMessagesMessage")).Begin(this);
			}
			if ((this.ReplyList.TwitterCollectionSource != null) && (this.ReplyList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("ShowNoRepliesMessage")).Begin(this);
			}
			this.NewRepliesCount = 0;
			if (this.UIList.get_SelectedItem() == this.ReplyList)
			{
				this.ReplyList.List.ScrollToBegin();
			}
			else
			{
				if (this.UIList.get_SelectedItem() == this.UserViewer)
				{
					this.UserViewer.UninitUserView();
				}
				this.UIList.ScrollToItem(this.ReplyList);
				this.UIList.set_SelectedItem(this.ReplyList);
			}
		}

		public void HideFailWhale()
		{
			if (this.HasConnectivity)
			{
				((Storyboard) base.FindResource("ExitTwitterDown")).Begin(this);
				this.TwitterDownWhales.Stop();
			}
		}

		private void HideNoConnectivity_Completed(object sender, EventArgs e)
		{
			if (this.couldntStartUp && !this.isRunning)
			{
				this.couldntStartUp = false;
				this.UIStartupAnimator_Completed(null, null);
			}
		}

		private void HookUpAPIEvenHandlers()
		{
			try
			{
				App.TwitterSource.add_Error(new ErrorHandler(this, (IntPtr) this.TwitterSource_Error));
				App.TwitterSource.add_CurrentFriendTimelineProcessed(new CurrentFriendTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_CurrentFriendTimelineProcessed));
				App.TwitterSource.add_ArchivedFriendTimelineProcessed(new ArchivedFriendTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_ArchivedFriendTimelineProcessed));
				App.TwitterSource.add_CurrentDirectMessagesProcessed(new CurrentDirectMessagesProcessedHandler(this, (IntPtr) this.TwitterSource_CurrentDirectMessagesProcessed));
				App.TwitterSource.add_ArchivedDirectMessagesProcessed(new ArchivedDirectMessagesProcessedHandler(this, (IntPtr) this.TwitterSource_ArchivedDirectMessagesProcessed));
				App.TwitterSource.add_FavoriteFriendTimelineProcessed(new FavoriteFriendTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_FavoriteFriendTimelineProcessed));
				App.TwitterSource.add_ArchivedUserTimelineProcessed(new ArchivedUserTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_ArchivedUserTimelineProcessed));
				App.TwitterSource.add_CurrentRepliesTimelineProcessed(new CurrentRepliesTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_CurrentRepliesTimelineProcessed));
				App.TwitterSource.add_ArchivedRepliesTimelineProcessed(new ArchivedRepliesTimelineProcessedHandler(this, (IntPtr) this.TwitterSource_ArchivedRepliesTimelineProcessed));
				App.TwitterSource.add_TweetDeleted(new TweetDeletedHandler(this, (IntPtr) this.TwitterSource_TweetDeleted));
				App.TwitterSource.add_DirectMessageDeleted(new DirectMessageDeletedHandler(this, (IntPtr) this.TwitterSource_DirectMessageDeleted));
				App.TwitterSource.add_ReplyCreated(new ReplyCreatedHandler(this, (IntPtr) this.TwitterSource_ReplyCreated));
				App.TwitterSource.add_DirectMessageCreated(new DirectMessageCreatedHandler(this, (IntPtr) this.TwitterSource_DirectMessageCreated));
				App.TwitterSource.add_LogoutProcessed(new LogoutProcessedHandler(this, (IntPtr) this.TwitterSource_LogoutProcessed));
				this.FriendList.HookUpAPIEvents();
				this.ReplyList.HookUpAPIEvents();
				this.DirectMessageList.HookUpAPIEvents();
				this.FavoriteFriendList.HookUpAPIEvents();
				this.UserViewer.HookUpAPIEvents();
			}
			catch (Exception exception)
			{
				this.ShowPopup("Unabled to load up valuable awesomes into the circuits. Maybe try running blu again. K? Bye!", PopupWindow.PopupWindowTypes.Error);
				bluHelper.WriteToLogger("Error during startup in HookUpAPIEvenHandlers method. " + Environment.NewLine + exception.Message + Environment.NewLine + exception.StackTrace, 1);
			}
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/mainwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void InsertByDate(TwitterData td)
		{
			if (this.FriendList.TwitterCollectionSource != null)
			{
				for (int i = 0; i < this.FriendList.TwitterCollectionSource.Count; i++)
				{
					if (td.get_DateCreated() > this.FriendList.TwitterCollectionSource[i].get_DateCreated())
					{
						this.FriendList.TwitterCollectionSource.Insert(i, td);
						return;
					}
				}
			}
		}

		private void List_TwitterDataCreation(object sender, bluRoutedEventArgs e)
		{
			this.StartWorking();
			if (e.get_Data().GetType() == typeof(Tweet))
			{
				App.TwitterSource.CreateReply(((Tweet) e.get_Data()).get_Text(), ((Tweet) e.get_Data()).get_ReplyToStatusId().ToString());
			}
			else if (e.get_Data().GetType() == typeof(DirectMessage))
			{
				App.TwitterSource.CreateDirectMessage(((DirectMessage) e.get_Data()).get_Recipient().get_Id().ToString(), ((DirectMessage) e.get_Data()).get_Text());
			}
		}

		private void List_TwitterDataDeletion(object sender, bluRoutedEventArgs e)
		{
			this.StartWorking();
			if (e.get_Data().GetType() == typeof(Tweet))
			{
				App.TwitterSource.DeleteTweet(((TwitterData) e.get_Data()).get_Id().ToString());
			}
			else if (e.get_Data().GetType() == typeof(DirectMessage))
			{
				App.TwitterSource.DeleteDirectMessage(((TwitterData) e.get_Data()).get_Id().ToString());
			}
			this.RemoveData(e.get_Data() as TwitterData);
		}

		private void LoadImageSequences()
		{
			try
			{
				this.assembly = Assembly.GetExecutingAssembly();
				this.NoConnectivityBird.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.ConnectivityLoss.base_", ".png", this.assembly, 0, 0x19, 5));
				this.bluSequence.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.Opening.chirp_opening", ".png", this.assembly, 5, 0x41, 5));
				this.AppWindowSequence.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.Window.window_", ".png", this.assembly, 1, 7, 5));
				this.RandomLogoIconFlapping.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.RandomFlap.bird_flap_", ".png", this.assembly, 0, 0x10, 5));
				this.WorkingSequence.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.Working.border_loading", ".png", this.assembly, 0, 0x15, 5));
			}
			catch (Exception exception)
			{
				this.ShowPopup("Unabled to load up valuable awesomes into the circuits. Maybe try running blu again. K? Bye!", PopupWindow.PopupWindowTypes.Error);
				bluHelper.WriteToLogger("Error during startup in LoadImageSequence method. " + Environment.NewLine + exception.Message + Environment.NewLine + exception.StackTrace, 1);
			}
		}

		public void LoadLockSequence()
		{
			this.LockSequence.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.LockedProfile.LockAnimation.lock_ani_", ".png", this.assembly, 2, 15, 5));
		}

		private void LoadSounds()
		{
			Assembly executingAssembly = Assembly.GetExecutingAssembly();
			this.openingStream = executingAssembly.GetManifestResourceStream("blu.Resources.Sounds.blu_opening_sound.wav");
			this.slideInStream = executingAssembly.GetManifestResourceStream("blu.Resources.Sounds.blu_login_slide.wav");
		}

		public void LoadTwitterDownWhales()
		{
			this.TwitterDownWhales.set_Images(bluHelper.LoadBitmapSourceArrayFromManifest("blu.Resources.Images.TwitterDown.WhaleSequence.fail_", ".png", this.assembly, 0, 0x18, 5));
		}

		private void Loginner_LoggedIn(object sender, RoutedEventArgs e)
		{
			if (!this.hasStartedUp)
			{
				this.HookUpAPIEvenHandlers();
				this.NoFavoritesMessage.DataContext = App.TwitterSource;
			}
			this.hasStartedUp = true;
			this.isRunning = true;
			this.PlayLogin();
			this.UIList.ScrollToItem(this.SecondFiller);
			this.UIList.set_SelectedItem(this.SecondFiller);
			((Storyboard) base.FindResource("NavigationAnimator")).Begin(this);
			this.NavigationContainer.IsHitTestVisible = true;
			this.Refresh();
		}

		private void MainWindow_Closed(object sender, EventArgs e)
		{
			NetworkChange.NetworkAvailabilityChanged -= new NetworkAvailabilityChangedEventHandler(this.NetworkChange_NetworkAvailabilityChanged);
			SystemEvents.PowerModeChanged -= new PowerModeChangedEventHandler(this.SystemEvents_PowerModeChanged);
		}

		private void MergeOldTwitterData(TwitterDataCollection collection, TwitterDataCollection incoming)
		{
			if (collection == null)
			{
				collection = incoming;
			}
			else
			{
				foreach (TwitterData data in incoming)
				{
					if (!collection.Contains(data))
					{
						collection.Add(data);
					}
				}
			}
		}

		private void MessagesNewCount_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.NewMessagesCount = this.newMessagesCountBuffer = 0;
		}

		private void Minimize_Click(object sender, RoutedEventArgs e)
		{
			base.WindowState = WindowState.Minimized;
		}

		private void NavigationAimator_Completed(object sender, EventArgs e)
		{
			this.CurrentTimeline = Timelines.Friends;
			this.UIList.ScrollToItem(this.FriendList);
			this.UIList.set_SelectedItem(this.FriendList);
		}

		private void NetworkChange_NetworkAvailabilityChanged(object sender, NetworkAvailabilityEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.HasConnectivity = e.IsAvailable;
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new NetworkAvailabilityChangedHandler(this.NetworkChange_NetworkAvailabilityChanged), sender, new object[] { e });
			}
		}

		private void newCountTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.newCountTimer.Stop();
				if (this.newFavoritesCountBuffer > 0)
				{
					this.NewFavoritesCount = this.newFavoritesCountBuffer;
					this.newFavoritesCountBuffer = 0;
				}
				if (this.newTweetsCountBuffer > 0)
				{
					this.NewTweetsCount = this.newTweetsCountBuffer;
					this.newTweetsCountBuffer = 0;
				}
				if (this.newMessagesCountBuffer > 0)
				{
					this.NewMessagesCount = this.newMessagesCountBuffer;
					this.newMessagesCountBuffer = 0;
				}
				if (this.newRepliesCountBuffer > 0)
				{
					this.NewRepliesCount = this.newRepliesCountBuffer;
					this.newRepliesCountBuffer = 0;
				}
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new NewCountTimerElapsedHandler(this.newCountTimer_Elapsed), sender, new object[] { e });
			}
		}

		private void NoConnectivityBird_Completed(object sender, RoutedEventArgs e)
		{
			if (this.NoConnectivityBird.get_IsReversed())
			{
				this.NoConnectivityBird.Opacity = 0.0;
				this.RandomLogoIconFlapping.Visibility = Visibility.Visible;
			}
		}

		private void NotifyPropertyChanged(string info)
		{
			if (this.PropertyChanged != null)
			{
				this.PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}

		private static void OnApplicationOpacityChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			App.BluCredentials.ApplicationOpacity = (double) e.NewValue;
			MainWindow window = d as MainWindow;
			if (window != null)
			{
				window.AnimateApplicationOpacity();
			}
		}

		private static void OnHasConnectivityChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			MainWindow containingObject = d as MainWindow;
			if (containingObject != null)
			{
				if ((bool) e.NewValue)
				{
					containingObject.StopWorking();
					containingObject.PlayLogin();
					((Storyboard) containingObject.FindResource("HideNoConnectivity")).Begin(containingObject);
					containingObject.NoConnectivityBird.set_IsReversed(true);
					containingObject.NoConnectivityBird.Start();
					containingObject.NoConnectivityBird.set_InactiveFrame(0);
				}
				else
				{
					containingObject.StopWorking();
					containingObject.CurrentTimeline = Timelines.Undefined;
					if ((!containingObject.couldntStartUp || (containingObject.couldntStartUp && containingObject.hasStartedUp)) || !containingObject.bluLogoPlaying)
					{
						((Storyboard) containingObject.FindResource("ShowNoConnectivity")).Begin(containingObject);
						if (containingObject.isRunning)
						{
							containingObject.TwitterDataCreator.Hide();
							containingObject.NoConnectivityWrapper.Visibility = Visibility.Collapsed;
						}
						else
						{
							containingObject.NoConnectivityWrapper.Visibility = Visibility.Visible;
						}
					}
					if (!containingObject.isRunning && !containingObject.bluLogoPlaying)
					{
						containingObject.UIList.ScrollToItem(containingObject.FirstFiller);
						containingObject.UIList.set_SelectedItem(containingObject.FirstFiller);
						containingObject.couldntStartUp = true;
						containingObject.UIStartupAnimator_Completed(null, null);
					}
				}
			}
		}

		private static void OnTwitterRefreshIntervalChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			if (App.BluCredentials.RefreshIntervalInMinutes != ((double) e.NewValue))
			{
				App.BluCredentials.RefreshIntervalInMinutes = (double) e.NewValue;
			}
			MainWindow window = d as MainWindow;
			if ((window != null) && (window.updateTimer != null))
			{
				window.updateTimer.Interval = window.TwitterRefreshInterval * 60000.0;
			}
		}

		private void PauseStartup()
		{
			this.startUpPause = new Timer(100.0);
			this.startUpPause.Elapsed += new ElapsedEventHandler(this.startUpPause_Elapsed);
			this.startUpPause.Start();
		}

		private void PlayLogin()
		{
			this.slideInStream.Position = 0L;
			this.slidein.Stream = null;
			this.slidein.Stream = this.slideInStream;
			this.slidein.Play();
		}

		private void PlayOpening()
		{
			this.openingStream.Position = 0L;
			this.intro.Stream = null;
			this.intro.Stream = this.openingStream;
			this.intro.Play();
		}

		private void RandomLogoIconFlapping_Completed(object sender, RoutedEventArgs e)
		{
			this.flapTimer.Interval = this.flapRandomizer.Next(0x1d4c0, 0x2bf20);
			this.flapTimer.Start();
		}

		private void Refresh()
		{
			if (this.HasConnectivity)
			{
				this.lastErrorMessage = string.Empty;
				this.updateTimer.Stop();
				this.StartWorking();
				App.TwitterSource.GetFriendTimeline();
				App.TwitterSource.GetDirectMessages();
				App.TwitterSource.GetRepliesTimeline();
				this.updateTimer.Start();
			}
		}

		private void RefreshTweets_Click(object sender, RoutedEventArgs e)
		{
			this.Refresh();
		}

		private void RemoveData(TwitterData twitterData)
		{
			if ((((this.FriendList.TwitterCollectionSource != null) && !this.FriendList.TwitterCollectionSource.Remove(twitterData)) && ((this.DirectMessageList.TwitterCollectionSource != null) && !this.DirectMessageList.TwitterCollectionSource.Remove(twitterData))) && (((this.FavoriteFriendList.TwitterCollectionSource != null) && !this.FavoriteFriendList.TwitterCollectionSource.Remove(twitterData)) && (this.UserViewer.TwitterCollectionSource != null)))
			{
				this.UserViewer.TwitterCollectionSource.Remove(twitterData);
			}
		}

		private void RepliesNewCount_MouseDown(object sender, MouseButtonEventArgs e)
		{
			this.NewRepliesCount = this.newRepliesCountBuffer = 0;
		}

		private void ReplyList_GetMoreTwitterData(object sender, RoutedEventArgs e)
		{
			this.StartWorking();
			App.TwitterSource.GetRepliesTimeline(this.currentRepliesTimelinePage);
			this.currentRepliesTimelinePage++;
		}

		private void Rooty_KeyDown(object sender, KeyEventArgs e)
		{
			if ((e.Key == Key.U) && !this.TwitterDataCreator.IsVisible)
			{
				this.CreateTweet_Click(null, null);
			}
		}

		private void SetLocation()
		{
			if (App.BluCredentials.WindowLocation.X < 0.0)
			{
				base.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			}
			else
			{
				base.WindowStartupLocation = WindowStartupLocation.Manual;
				base.Left = App.BluCredentials.WindowLocation.X;
				base.Top = App.BluCredentials.WindowLocation.Y;
			}
		}

		private void Settings_Click(object sender, RoutedEventArgs e)
		{
			this.SettingsPopup.Show();
		}

		private void SetUpFlapTimer()
		{
			this.flapRandomizer = new Random(DateTime.Now.Millisecond);
			this.flapTimer = new Timer((double) this.flapRandomizer.Next(0x1d4c0, 0x2bf20));
			this.flapTimer.Elapsed += new ElapsedEventHandler(this.flapTimer_Elapsed);
		}

		public void ShowFailWhale()
		{
			if (this.TwitterDownWhales.get_Images() == null)
			{
				this.LoadTwitterDownWhales();
			}
			this.TwitterDataCreator.Hide();
			if (this.HasConnectivity)
			{
				((Storyboard) base.FindResource("EnterTwitterDown")).Begin(this);
				this.TwitterDownWhales.Start();
			}
		}

		private void ShowNoConnectivity_Completed(object sender, EventArgs e)
		{
			this.RandomLogoIconFlapping.Visibility = Visibility.Collapsed;
			this.NoConnectivityBird.Opacity = 1.0;
			this.NoConnectivityBird.set_IsReversed(false);
			this.NoConnectivityBird.Start();
			this.NoConnectivityBird.set_InactiveFrame(0x19);
		}

		public void ShowPopup(string text, PopupWindow.PopupWindowTypes type)
		{
			try
			{
				PopupWindow window = new PopupWindow();
				window.PopupWindowText = text;
				window.PopupWindowType = type;
				window.Owner = Application.Current.MainWindow;
				window.ShowDialog();
			}
			catch (Exception exception)
			{
				bluHelper.WriteToLogger("Tried to show a popup but was unable. Here's why: " + exception.Message + Environment.NewLine + "StackTrace: " + exception.StackTrace + Environment.NewLine + "Popup message: " + text, 1);
			}
		}

		private void startUpPause_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.startUpPause.Stop();
				this.AppWindowSequence.Start();
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new StartUpPauseTimerElapsedHandler(this.startUpPause_Elapsed), sender, new object[] { e });
			}
		}

		public void StartWorking()
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.WorkingSequence.Start();
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new NoArgDelegateHandler(this.StartWorking));
			}
		}

		public void StopWorking()
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.WorkingSequence.Stop();
				((Storyboard) base.FindResource("DoneWorkingGlowAnimator")).Begin(this);
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new NoArgDelegateHandler(this.StartWorking));
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.MainWin = (MainWindow) target;
					return;

				case 2:
					((Storyboard) target).Completed += new EventHandler(this.UIStartupAnimator_Completed);
					return;

				case 3:
					((Storyboard) target).Completed += new EventHandler(this.UIExitAnimator_Completed);
					return;

				case 4:
					((Storyboard) target).Completed += new EventHandler(this.NavigationAimator_Completed);
					return;

				case 5:
					((Storyboard) target).Completed += new EventHandler(this.ShowNoConnectivity_Completed);
					return;

				case 6:
					((Storyboard) target).Completed += new EventHandler(this.HideNoConnectivity_Completed);
					return;

				case 7:
					this.Rooty = (Grid) target;
					this.Rooty.PreviewKeyDown += new KeyEventHandler(this.Rooty_KeyDown);
					return;

				case 8:
					this.AppBackground = (Image) target;
					return;

				case 9:
					this.AppWindowSequence = (ImageSequence) target;
					this.AppWindowSequence.add_Completed(new RoutedEventHandler(this.AppWindowSequence_Completed));
					this.AppWindowSequence.add_FrameChanged(new RoutedEventHandler(this.AppWindowSequence_FrameChanged));
					this.AppWindowSequence.add_Ready(new RoutedEventHandler(this.AppWindowSequence_Ready));
					return;

				case 10:
					this.bluSequence = (ImageSequence) target;
					this.bluSequence.add_Completed(new RoutedEventHandler(this.bluSequence_Completed));
					this.bluSequence.add_FrameChanged(new RoutedEventHandler(this.bluSequence_FrameChanged));
					this.bluSequence.add_Ready(new RoutedEventHandler(this.bluSequence_Ready));
					return;

				case 11:
					this.ContentRoot = (Border) target;
					return;

				case 12:
					this.Dragger = (Thumb) target;
					this.Dragger.DragDelta += new DragDeltaEventHandler(this.Dragger_DragDelta);
					return;

				case 13:
					this.UIListEffectEnabler = (Grid) target;
					return;

				case 14:
					this.UIList = (DeferredSelectionListBox) target;
					return;

				case 15:
					this.FirstFiller = (Border) target;
					return;

				case 0x10:
					this.Loginner = (LoginComponent) target;
					return;

				case 0x11:
					this.SecondFiller = (Border) target;
					return;

				case 0x12:
					this.FavoriteFriendList = (TwitterDataListComponent) target;
					return;

				case 0x13:
					this.FriendList = (TwitterDataListComponent) target;
					return;

				case 20:
					this.ReplyList = (TwitterDataListComponent) target;
					return;

				case 0x15:
					this.DirectMessageList = (TwitterDataListComponent) target;
					return;

				case 0x16:
					this.UserViewer = (TwitterDataListComponent) target;
					return;

				case 0x17:
					this.NoFavoritesMessage = (Grid) target;
					return;

				case 0x18:
					this.NoMessagesMessage = (Grid) target;
					return;

				case 0x19:
					this.NoRepliesMessage = (Grid) target;
					return;

				case 0x1a:
					this.AppTop = (Image) target;
					return;

				case 0x1b:
					this.WindowControlContainer = (Grid) target;
					return;

				case 0x1c:
					this.WindowControlTranslater = (TranslateTransform) target;
					return;

				case 0x1d:
					this.Settings = (ImageButton) target;
					this.Settings.Click += new RoutedEventHandler(this.Settings_Click);
					return;

				case 30:
					this.Minimize = (ImageButton) target;
					this.Minimize.Click += new RoutedEventHandler(this.Minimize_Click);
					return;

				case 0x1f:
					this.Exit = (ImageButton) target;
					this.Exit.Click += new RoutedEventHandler(this.Exit_Click);
					return;

				case 0x20:
					this.NavigationContainer = (Grid) target;
					return;

				case 0x21:
					this.AppBottom = (Image) target;
					return;

				case 0x22:
					this.GoToFavorites = (ImageButton) target;
					this.GoToFavorites.Click += new RoutedEventHandler(this.GoToFavorites_Click);
					return;

				case 0x23:
					this.FavoritesScaler = (ScaleTransform) target;
					return;

				case 0x24:
					this.FavoritesText = (ContentControl) target;
					return;

				case 0x25:
					this.FavoritesTextT = (TranslateTransform) target;
					return;

				case 0x26:
					this.FavoritesNewCount = (CountBubbleComponent) target;
					return;

				case 0x27:
					this.GoToHome = (ImageButton) target;
					this.GoToHome.Click += new RoutedEventHandler(this.GoToHome_Click);
					return;

				case 40:
					this.HomeScaler = (ScaleTransform) target;
					return;

				case 0x29:
					this.HomeText = (ContentControl) target;
					return;

				case 0x2a:
					this.HomeTextT = (TranslateTransform) target;
					return;

				case 0x2b:
					this.FriendsNewCount = (CountBubbleComponent) target;
					return;

				case 0x2c:
					this.GoToReplies = (ImageButton) target;
					this.GoToReplies.Click += new RoutedEventHandler(this.GoToReplies_Click);
					return;

				case 0x2d:
					this.RepliesScaler = (ScaleTransform) target;
					return;

				case 0x2e:
					this.RepliesText = (ContentControl) target;
					return;

				case 0x2f:
					this.RepliesTextT = (TranslateTransform) target;
					return;

				case 0x30:
					this.RepliesNewCount = (CountBubbleComponent) target;
					return;

				case 0x31:
					this.GoToMessages = (ImageButton) target;
					this.GoToMessages.Click += new RoutedEventHandler(this.GoToMessages_Click);
					return;

				case 50:
					this.MessagesScaler = (ScaleTransform) target;
					return;

				case 0x33:
					this.DirectText = (ContentControl) target;
					return;

				case 0x34:
					this.DirectTextT = (TranslateTransform) target;
					return;

				case 0x35:
					this.MessagesNewCount = (CountBubbleComponent) target;
					return;

				case 0x36:
					this.CreateTweet = (ImageButton) target;
					this.CreateTweet.Click += new RoutedEventHandler(this.CreateTweet_Click);
					return;

				case 0x37:
					this.CreateScaler = (ScaleTransform) target;
					return;

				case 0x38:
					this.UpdateText = (ContentControl) target;
					return;

				case 0x39:
					this.UpdateTextT = (TranslateTransform) target;
					return;

				case 0x3a:
					this.RefreshTweets = (ImageButton) target;
					this.RefreshTweets.Click += new RoutedEventHandler(this.RefreshTweets_Click);
					return;

				case 0x3b:
					this.RefreshScaler = (ScaleTransform) target;
					return;

				case 60:
					this.RefreshText = (ContentControl) target;
					return;

				case 0x3d:
					this.RefreshTextT = (TranslateTransform) target;
					return;

				case 0x3e:
					this.DoneWorkingGlow = (Image) target;
					return;

				case 0x3f:
					this.WorkingSequence = (ImageSequence) target;
					return;

				case 0x40:
					this.TwitterDataCreator = (CreateTweetComponent) target;
					return;

				case 0x41:
					this.RandomLogoIconFlapping = (ImageSequence) target;
					this.RandomLogoIconFlapping.add_Completed(new RoutedEventHandler(this.RandomLogoIconFlapping_Completed));
					return;

				case 0x42:
					this.LogoIconScaler = (ScaleTransform) target;
					return;

				case 0x43:
					this.TwitterDownBird = (Image) target;
					return;

				case 0x44:
					this.NoConnectivityBird = (ImageSequence) target;
					this.NoConnectivityBird.add_Completed(new RoutedEventHandler(this.NoConnectivityBird_Completed));
					return;

				case 0x45:
					this.TwitterDownWhales = (ImageSequence) target;
					return;

				case 70:
					this.CheckTwitterDown = (ImageButton) target;
					this.CheckTwitterDown.Click += new RoutedEventHandler(this.CheckTwitterDown_Click);
					return;

				case 0x47:
					this.NoConnectivityWrapper = (Grid) target;
					return;

				case 0x48:
					this.LogoTitle = (Image) target;
					return;

				case 0x49:
					this.LogoTitleScaler = (ScaleTransform) target;
					return;

				case 0x4a:
					this.LockSequence = (ImageSequence) target;
					return;

				case 0x4b:
					this.SettingsPopup = (SettingsComponent) target;
					return;
			}
			this._contentLoaded = true;
		}

		private void SystemEvents_PowerModeChanged(object sender, PowerModeChangedEventArgs e)
		{
			if (!base.Dispatcher.CheckAccess())
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new PowerModeChangedHandler(this.SystemEvents_PowerModeChanged), sender, new object[] { e });
			}
			else
			{
				switch (e.Mode)
				{
					case PowerModes.Resume:
						this.HasConnectivity = true;
						break;

					case PowerModes.Suspend:
						this.HasConnectivity = false;
						break;
				}
				bluHelper.WriteToLogger("PowerMode changed: " + e.Mode, 0);
			}
		}

		private void TwitterDataCreator_TweetCreationFailed(object sender, TwitterDataCreationFailedEventArgs e)
		{
			this.ShowPopup("Unable set status. " + e.FailureReason, PopupWindow.PopupWindowTypes.Error);
		}

		private void TwitterDataCreator_TweetCreationSuccessful(object sender, TwitterDataCreationSuccessfulEventArgs e)
		{
			if (this.FriendList.TwitterCollectionSource != null)
			{
				this.FriendList.TwitterCollectionSource.Insert(0, e.NewTwitterData);
				if (this.UIList.get_SelectedItem() != this.FriendList)
				{
					this.newTweetsCountBuffer = 1;
					if (!this.newCountTimer.Enabled)
					{
						this.newCountTimer.Start();
					}
				}
			}
		}

		private void TwitterSource_ArchivedDirectMessagesProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Error while getting past messages. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Information);
				this.currentDirectMessagePage--;
			}
			else if (this.DirectMessageList.TwitterCollectionSource != null)
			{
				int count = this.DirectMessageList.TwitterCollectionSource.Count;
				foreach (Tweet tweet in e.get_NewTwitterDataCollection())
				{
					this.DirectMessageList.TwitterCollectionSource.Add(tweet);
				}
				this.DirectMessageList.List.ScrollToItem(count);
			}
		}

		private void TwitterSource_ArchivedFriendTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Error while getting past tweets. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Information);
				this.currentFriendTimelinePage--;
			}
			else if (this.FriendList.TwitterCollectionSource != null)
			{
				int count = this.FriendList.TwitterCollectionSource.Count;
				foreach (Tweet tweet in e.get_NewTwitterDataCollection())
				{
					this.FriendList.TwitterCollectionSource.Add(tweet);
				}
				this.FriendList.List.ScrollToItem(count);
			}
		}

		private void TwitterSource_ArchivedRepliesTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Error while getting past replies. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Information);
				this.currentRepliesTimelinePage--;
			}
			else if (this.ReplyList.TwitterCollectionSource != null)
			{
				int count = this.ReplyList.TwitterCollectionSource.Count;
				foreach (Tweet tweet in e.get_NewTwitterDataCollection())
				{
					this.ReplyList.TwitterCollectionSource.Add(tweet);
				}
				this.ReplyList.List.ScrollToItem(count);
			}
		}

		private void TwitterSource_ArchivedUserTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Error while getting past tweets. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Information);
				this.currentUserViewPage--;
			}
			else if (this.UserViewer.TwitterCollectionSource != null)
			{
				int count = this.UserViewer.TwitterCollectionSource.Count;
				foreach (Tweet tweet in e.get_NewTwitterDataCollection())
				{
					this.UserViewer.TwitterCollectionSource.Add(tweet);
				}
				this.UserViewer.List.ScrollToItem(count);
			}
		}

		private void TwitterSource_CurrentDirectMessagesProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (e.get_RequestIsGood())
			{
				if (this.DirectMessageList.TwitterCollectionSource == null)
				{
					this.DirectMessageList.TwitterCollectionSource = e.get_NewTwitterDataCollection();
				}
				else
				{
					foreach (TwitterData data in e.get_NewTwitterDataCollection())
					{
						if (!this.DirectMessageList.TwitterCollectionSource.Contains(data))
						{
							this.DirectMessageList.TwitterCollectionSource.Insert(0, data);
						}
						else
						{
							this.DirectMessageList.TwitterCollectionSource.UpdateRelativeTime(data);
						}
					}
				}
				if (this.UIList.get_SelectedItem() != this.DirectMessageList)
				{
					this.newMessagesCountBuffer = Convert.ToInt32(e.get_AdditionalInfo());
					if ((this.newMessagesCountBuffer > 0) && !this.newCountTimer.Enabled)
					{
						this.newCountTimer.Start();
					}
				}
			}
			else if (!this.lastErrorMessage.Equals(e.get_FailureDetails()))
			{
				this.lastErrorMessage = e.get_FailureDetails();
				this.ShowPopup("Unable to get latest stuff from the Twitter mothership. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_CurrentFriendTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (e.get_RequestIsGood())
			{
				if (this.FriendList.TwitterCollectionSource == null)
				{
					if ((this.UIList.get_SelectedItem() != this.FriendList) && !this.startingUp)
					{
						this.newTweetsCountBuffer = Convert.ToInt32(e.get_AdditionalInfo());
						if ((this.newTweetsCountBuffer > 0) && !this.newCountTimer.Enabled)
						{
							this.newCountTimer.Start();
						}
					}
					if (!this.startingUp)
					{
						this.startingUp = false;
					}
					this.FriendList.TwitterCollectionSource = e.get_NewTwitterDataCollection();
				}
				else
				{
					foreach (TwitterData data in e.get_NewTwitterDataCollection())
					{
						if (!this.FriendList.TwitterCollectionSource.Contains(data))
						{
							this.InsertByDate(data);
						}
						else
						{
							this.FriendList.TwitterCollectionSource.UpdateRelativeTime(data);
						}
					}
					this.newTweetsCountBuffer = Convert.ToInt32(e.get_AdditionalInfo());
					if (((this.UIList.get_SelectedItem() != this.FriendList) && (this.newTweetsCountBuffer > 0)) && !this.newCountTimer.Enabled)
					{
						this.newCountTimer.Start();
					}
					if ((this.newTweetsCountBuffer > 0) && App.BluCredentials.SoundedUpdates)
					{
						this.PlayLogin();
					}
				}
			}
			else if (!this.lastErrorMessage.Equals(e.get_FailureDetails()))
			{
				this.lastErrorMessage = e.get_FailureDetails();
				this.ShowPopup("Unable to get latest stuff from the Twitter mothership. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_CurrentRepliesTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			this.StopWorking();
			if (e.get_RequestIsGood())
			{
				if (this.ReplyList.TwitterCollectionSource == null)
				{
					this.ReplyList.TwitterCollectionSource = e.get_NewTwitterDataCollection();
				}
				else
				{
					foreach (TwitterData data in e.get_NewTwitterDataCollection())
					{
						if (!this.ReplyList.TwitterCollectionSource.Contains(data))
						{
							this.ReplyList.TwitterCollectionSource.Insert(0, data);
						}
						else
						{
							this.ReplyList.TwitterCollectionSource.UpdateRelativeTime(data);
						}
					}
				}
				if (this.UIList.get_SelectedItem() != this.ReplyList)
				{
					this.newRepliesCountBuffer = Convert.ToInt32(e.get_AdditionalInfo());
					if ((this.newRepliesCountBuffer > 0) && !this.newCountTimer.Enabled)
					{
						this.newCountTimer.Start();
					}
				}
			}
			else if (!this.lastErrorMessage.Equals(e.get_FailureDetails()))
			{
				this.lastErrorMessage = e.get_FailureDetails();
				this.ShowPopup("Unable to get latest stuff from the Twitter mothership. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_DirectMessageCreated(object sender, TwitterDataCreatedEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Unable to create direct message. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_DirectMessageDeleted(object sender, bluEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Unable to delete direct message. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_Error(object sender, bluEventArgs e)
		{
			this.ShowPopup(e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
		}

		private void TwitterSource_FailWhale(object sender, EventArgs e)
		{
			if (this.HasConnectivity)
			{
				this.StopWorking();
				this.updateTimer.Stop();
				this.ShowFailWhale();
			}
		}

		private void TwitterSource_FavoriteFriendTimelineProcessed(object sender, TwitterDataCollectionCreatedEventArgs e)
		{
			if (e.get_RequestIsGood())
			{
				if (this.UIList.get_SelectedItem() != this.FavoriteFriendList)
				{
					this.newFavoritesCountBuffer = Convert.ToInt32(e.get_AdditionalInfo());
					if ((this.newFavoritesCountBuffer > 0) && !this.newCountTimer.Enabled)
					{
						this.newCountTimer.Start();
					}
				}
				this.FavoriteFriendList.TwitterCollectionSource = e.get_NewTwitterDataCollection();
			}
			else
			{
				this.ShowPopup("Unable to get favorite friend list. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_LogoutProcessed(object sender, bluEventArgs e)
		{
			if (this.TwitterDataCreator.IsVisible)
			{
				this.TwitterDataCreator.Hide();
			}
			this.CurrentTimeline = Timelines.Undefined;
			this.startingUp = true;
			this.isRunning = false;
			this.FavoriteFriendList.TwitterCollectionSource = null;
			this.FriendList.TwitterCollectionSource = null;
			this.ReplyList.TwitterCollectionSource = null;
			this.DirectMessageList.TwitterCollectionSource = null;
			this.StopWorking();
			this.Loginner.Show();
			this.UIList.ScrollToItem(this.Loginner);
			this.UIList.set_SelectedItem(this.Loginner);
			((Storyboard) base.FindResource("NavigationLeaveAnimator")).Begin(this);
			this.NavigationContainer.IsHitTestVisible = false;
			App.TwitterSource.PersistSettings();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Error while logging you out. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Information);
			}
		}

		private void TwitterSource_ReplyCreated(object sender, TwitterDataCreatedEventArgs e)
		{
			this.StopWorking();
			if (e.get_RequestIsGood())
			{
				this.FriendList.TwitterCollectionSource.Insert(0, e.get_NewTwitterData());
			}
			else
			{
				this.ShowPopup("Unable to create reply. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_TestTwitterProcessed(object sender, bluEventArgs e)
		{
			if (e.get_RequestIsGood() && e.get_AdditionalInfo().Equals("true"))
			{
				this.HideFailWhale();
				if (this.isRunning)
				{
					this.Refresh();
				}
				else
				{
					this.UIStartupAnimator_Completed(null, null);
				}
			}
			else
			{
				this.ShowPopup("Unable to login. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void TwitterSource_TweetDeleted(object sender, bluEventArgs e)
		{
			this.StopWorking();
			if (!e.get_RequestIsGood())
			{
				this.ShowPopup("Unable to delete tweet. " + e.get_FailureDetails(), PopupWindow.PopupWindowTypes.Error);
			}
		}

		private void UIExitAnimator_Completed(object sender, EventArgs e)
		{
			this.AppWindowSequence.set_IsReversed(true);
			this.AppWindowSequence.Start();
		}

		private void UIStartupAnimator_Completed(object sender, EventArgs e)
		{
			if (this.HasConnectivity)
			{
				this.UIListEffectEnabler.IsHitTestVisible = true;
				this.Loginner.Show();
				this.UIList.ScrollToItem(this.Loginner);
				this.UIList.set_SelectedItem(this.Loginner);
				if (App.BluCredentials.AutomaticallyLogin && !App.IsLoggingIn)
				{
					this.Loginner.StartAutoLogin();
				}
			}
			else
			{
				this.couldntStartUp = true;
			}
			if (this.bluSequence.get_Images() != null)
			{
				this.bluSequence.set_Images(null);
				GC.Collect();
			}
		}

		private void UpdateListsForAddingFriend(int p)
		{
			foreach (Tweet tweet in this.FriendList.TwitterCollectionSource)
			{
				if (tweet.get_User().get_Id() == p)
				{
					tweet.get_User().set_IsFavoriteFriend(true);
				}
			}
			this.NewFavoritesCount++;
		}

		private void UpdateListsForRemovingFriend(int p)
		{
			int num;
			foreach (Tweet tweet in this.FriendList.TwitterCollectionSource)
			{
				if (tweet.get_User().get_Id() == p)
				{
					tweet.get_User().set_IsFavoriteFriend(false);
				}
			}
			this.NewFavoritesCount = (num = this.NewFavoritesCount) - 1;
			this.NewFavoritesCount = Math.Min(0, num);
		}

		private void updateTimer_Elapsed(object sender, ElapsedEventArgs e)
		{
			if (base.Dispatcher.CheckAccess())
			{
				this.Refresh();
			}
			else
			{
				base.Dispatcher.BeginInvoke(DispatcherPriority.Normal, new UpdateTimerElapsedHandler(this.updateTimer_Elapsed), sender, new object[] { e });
			}
		}

		private void UserViewer_FavoriteFriend(object sender, bluRoutedEventArgs e)
		{
			this.FavoriteFriendList.TwitterCollectionSource = App.TwitterSource.AddFavoriteFriend(e.get_Data() as Tweet);
			this.UpdateListsForAddingFriend(((Tweet) e.get_Data()).get_User().get_Id());
		}

		private void UserViewer_GetMoreTwitterData(object sender, RoutedEventArgs e)
		{
			this.StartWorking();
			App.TwitterSource.GetUserTimeline(this.currentUserId, this.currentUserViewPage);
			this.currentUserViewPage++;
		}

		private void UserViewer_UnFavoriteFriend(object sender, bluRoutedEventArgs e)
		{
			this.FavoriteFriendList.TwitterCollectionSource = App.TwitterSource.RemoveFavoriteFriend(e.get_Data() as Tweet);
			this.UpdateListsForRemovingFriend(((Tweet) e.get_Data()).get_User().get_Id());
		}

		private void UserViewRequest(object sender, bluRoutedEventArgs e)
		{
			if (((this.UIList.get_SelectedItem() == this.FavoriteFriendList) && (this.FavoriteFriendList.TwitterCollectionSource != null)) && (this.FavoriteFriendList.TwitterCollectionSource.Count == 0))
			{
				((Storyboard) base.FindResource("HideNoFavoritesMessage")).Begin(this);
			}
			this.CurrentTimeline = Timelines.Undefined;
			this.currentUserViewPage = 2;
			this.currentUserId = ((User) e.get_Data()).get_Id().ToString();
			this.UserViewer.InitUserView(e.get_Data() as User);
			this.UIList.ScrollToItem(this.UserViewer);
			this.UIList.set_SelectedItem(this.UserViewer);
		}

		// Properties
		public double ApplicationOpacity
		{
			get
			{
				return (double) base.GetValue(ApplicationOpacityProperty);
			}
			set
			{
				base.SetValue(ApplicationOpacityProperty, value);
			}
		}

		public bool ComponentIsFlipped
		{
			get
			{
				return this.componentIsFlipped;
			}
			set
			{
				this.componentIsFlipped = value;
				if (this.componentIsFlipped && this.TwitterDataCreator.IsVisible)
				{
					this.TwitterDataCreator.Hide();
				}
			}
		}

		public Timelines CurrentTimeline
		{
			get
			{
				return (Timelines) base.GetValue(CurrentTimelineProperty);
			}
			set
			{
				base.SetValue(CurrentTimelineProperty, value);
			}
		}

		public bool HasConnectivity
		{
			get
			{
				return (bool) base.GetValue(HasConnectivityProperty);
			}
			set
			{
				base.SetValue(HasConnectivityProperty, value);
			}
		}

		public int NewFavoritesCount
		{
			get
			{
				return (int) base.GetValue(NewFavoritesCountProperty);
			}
			set
			{
				base.SetValue(NewFavoritesCountProperty, value);
			}
		}

		public int NewMessagesCount
		{
			get
			{
				return (int) base.GetValue(NewMessagesCountProperty);
			}
			set
			{
				base.SetValue(NewMessagesCountProperty, value);
			}
		}

		public int NewRepliesCount
		{
			get
			{
				return (int) base.GetValue(NewRepliesCountProperty);
			}
			set
			{
				base.SetValue(NewRepliesCountProperty, value);
			}
		}

		public int NewTweetsCount
		{
			get
			{
				return (int) base.GetValue(NewTweetsCountProperty);
			}
			set
			{
				base.SetValue(NewTweetsCountProperty, value);
			}
		}

		public double TwitterRefreshInterval
		{
			get
			{
				return (double) base.GetValue(TwitterRefreshIntervalProperty);
			}
			set
			{
				base.SetValue(TwitterRefreshIntervalProperty, value);
			}
		}

		// Nested Types
		private delegate void FlapTimerElapsedHandler(object sender, ElapsedEventArgs e);

		private delegate void NetworkAvailabilityChangedHandler(object sender, NetworkAvailabilityEventArgs e);

		private delegate void NewCountTimerElapsedHandler(object sender, ElapsedEventArgs e);

		private delegate void NoArgDelegateHandler();

		private delegate void PowerModeChangedHandler(object sender, PowerModeChangedEventArgs e);

		private delegate void StartUpPauseTimerElapsedHandler(object sender, ElapsedEventArgs e);

		public enum Timelines
		{
			Undefined,
			Friends,
			FavoriteFriends,
			DirectMessages,
			Replies
		}

		private delegate void UpdateTimerElapsedHandler(object sender, ElapsedEventArgs e);
	}
}