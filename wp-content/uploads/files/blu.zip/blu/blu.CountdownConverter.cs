namespace blu
{
	[ValueConversion(typeof(int), typeof(string))]
	public class CountdownConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			object obj2;
			int num = 140;
			try
			{
				num -= (int) value;
				if (num < 0)
				{
					return (Math.Abs(num).ToString() + "!");
				}
				obj2 = num.ToString();
			}
			catch
			{
			}
			return obj2;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0;
		}
	}
}