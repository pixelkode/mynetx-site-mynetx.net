namespace blu
{
	public class CountBubbleComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		public static readonly DependencyProperty NewCountProperty = DependencyProperty.Register("NewCount", typeof(int), typeof(CountBubbleComponent), new FrameworkPropertyMetadata(0, new PropertyChangedCallback(CountBubbleComponent.OnNewCountChanged)));
		internal ContentControl Number;
		internal Grid Rooty;
		internal ScaleTransform Scaler;

		// Methods
		public CountBubbleComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
			base.DataContext = this;
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at count bubble component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/countbubblecomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private static void OnNewCountChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			CountBubbleComponent containingObject = d as CountBubbleComponent;
			if (((int) e.NewValue) == 0)
			{
				((Storyboard) containingObject.FindResource("BubbleOut")).Begin(containingObject);
				containingObject.IsHitTestVisible = false;
			}
			else
			{
				((Storyboard) containingObject.FindResource("BubbleIn")).Begin(containingObject);
				containingObject.IsHitTestVisible = true;
			}
		}

		[DebuggerNonUserCode, EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.Rooty = (Grid) target;
					return;

				case 2:
					this.Scaler = (ScaleTransform) target;
					return;

				case 3:
					this.Number = (ContentControl) target;
					return;
			}
			this._contentLoaded = true;
		}

		// Properties
		public int NewCount
		{
			get
			{
				return (int) base.GetValue(NewCountProperty);
			}
			set
			{
				base.SetValue(NewCountProperty, value);
			}
		}
	}
}