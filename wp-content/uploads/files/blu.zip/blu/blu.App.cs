namespace blu
{
	public class App : Application
	{
		// Fields
		private bool _contentLoaded;
		private static bluCredentials bluCredentials;
		private static string credentialsObjectPath = (Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) + @"\thirteen23\blu\Credentials");
		private static bool isLoggingIn;
		public static User LoggedInUser;
		private List<Assembly> resolvedAssemblies = new List<Assembly>();
		private static TwitterAPIWrapper twitterSource;

		// Methods
		static App()
		{
			AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(App.CurrentDomain_AssemblyResolve);
		}

		private void Application_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
		{
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an error that it doesn't know how to handle and must exit. If logging has been turned on, more details are probably in that file. See ya!", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at App level: " + e.Exception.Message + Environment.NewLine + "StackTrace: " + e.Exception.StackTrace, 1);
			if (e.Exception.InnerException != null)
			{
				bluHelper.WriteToLogger("Unhandled dispatcher exception at App level: " + e.Exception.InnerException.Message + Environment.NewLine + "StackTrace: " + e.Exception.InnerException.StackTrace, 1);
				if (e.Exception.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger("Unhandled dispatcher exception at App level: " + e.Exception.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + e.Exception.InnerException.InnerException.StackTrace, 1);
				}
			}
			Application.Current.Shutdown();
		}

		private void Application_Startup(object sender, StartupEventArgs e)
		{
			AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(this.NonStaticCurrentDomain_AssemblyResolve);
		}

		private static Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
		{
			string[] manifestResourceNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();
			if (args.Name.Contains(","))
			{
				string str = "blu.Resources." + args.Name.Substring(0, args.Name.IndexOf(","));
				foreach (string str2 in manifestResourceNames)
				{
					string str3 = str2.Substring(0, str2.LastIndexOf('.'));
					if (str == str3)
					{
						try
						{
							Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(str2);
							byte[] buffer = new byte[(int) manifestResourceStream.Length];
							manifestResourceStream.Read(buffer, 0, (int) manifestResourceStream.Length);
							Assembly assembly = Assembly.Load(buffer);
							if (args.Name == assembly.GetName().FullName)
							{
								return assembly;
							}
						}
						catch
						{
						}
					}
				}
			}
			return null;
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				base.DispatcherUnhandledException += new DispatcherUnhandledExceptionEventHandler(this.Application_DispatcherUnhandledException);
				base.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
				Uri resourceLocator = new Uri("/blu;component/app.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode, STAThread]
		public static void Main()
		{
			App app = new App();
			app.InitializeComponent();
			app.Run();
		}

		private Assembly NonStaticCurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
		{
			string[] manifestResourceNames = Assembly.GetExecutingAssembly().GetManifestResourceNames();
			foreach (Assembly assembly in this.resolvedAssemblies)
			{
				if (assembly.GetName().Name == args.Name)
				{
					return assembly;
				}
			}
			if (args.Name.Contains(","))
			{
				string str = "Thirteen23." + args.Name.Substring(0, args.Name.IndexOf(","));
				foreach (string str2 in manifestResourceNames)
				{
					string str3 = str2.Substring(0, str2.LastIndexOf('.'));
					if (str == str3)
					{
						Assembly assembly3;
						try
						{
							Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(str2);
							byte[] buffer = new byte[(int) manifestResourceStream.Length];
							manifestResourceStream.Read(buffer, 0, (int) manifestResourceStream.Length);
							Assembly item = Assembly.Load(buffer);
							if (!(args.Name == item.GetName().FullName))
							{
								goto Label_012C;
							}
							this.resolvedAssemblies.Add(item);
							assembly3 = item;
						}
						catch
						{
						}
						return assembly3;
					Label_012C:;
					}
				}
			}
			return null;
		}

		protected override void OnExit(ExitEventArgs e)
		{
			if ((TwitterSource != null) && TwitterSource.get_IsLoggedIn())
			{
				TwitterSource.PersistSettings();
			}
			base.OnExit(e);
		}

		protected override void OnStartup(StartupEventArgs e)
		{
			base.OnStartup(e);
		}

		// Properties
		public static bluCredentials BluCredentials
		{
			get
			{
				if (bluCredentials == null)
				{
					try
					{
						bluCredentials = CredentialsHelper.DeserializeObject(CredentialsObjectPath) as bluCredentials;
					}
					catch (Exception exception)
					{
						bluHelper.WriteToLogger("Unable to deserialize credentials. " + exception.Message + Environment.NewLine + exception.StackTrace, 1);
					}
					if (bluCredentials == null)
					{
						bluCredentials = new bluCredentials();
						bluCredentials.ApplicationOpacity = 75.0;
						bluCredentials.AutomaticallyLogin = false;
						bluCredentials.EnableLogging = false;
						bluCredentials.RefreshIntervalInMinutes = 4.0;
						bluCredentials.RememberLoginInfo = false;
						bluCredentials.SoundedUpdates = false;
						bluCredentials.WindowLocation = new Point(-1.0, -1.0);
					}
					else
					{
						bluCredentials.Decrypt();
						if (bluCredentials.get_UserName() == null)
						{
							bluCredentials.set_UserName(string.Empty);
						}
						if (bluCredentials.get_Password() == null)
						{
							bluCredentials.set_Password(string.Empty);
						}
					}
				}
				return bluCredentials;
			}
			set
			{
				bluCredentials = value;
			}
		}

		public static string CredentialsObjectPath
		{
			get
			{
				return credentialsObjectPath;
			}
			set
			{
				credentialsObjectPath = value;
			}
		}

		public static bool IsLoggingIn
		{
			get
			{
				return isLoggingIn;
			}
			set
			{
				isLoggingIn = value;
			}
		}

		public static TwitterAPIWrapper TwitterSource
		{
			get
			{
				if (twitterSource == null)
				{
					twitterSource = new TwitterAPIWrapper();
				}
				return twitterSource;
			}
			set
			{
				twitterSource = value;
			}
		}
	}
}