namespace blu
{
	public class PopupWindow : Window, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		internal ImageButton CloseDialog;
		internal Image ErrorImage;
		internal Image InfoImage;
		internal PopupWindow mainWin;
		public static readonly DependencyProperty PopupWindowTextProperty = DependencyProperty.Register("PopupWindowText", typeof(string), typeof(PopupWindow));
		public static readonly DependencyProperty PopupWindowTypeProperty = DependencyProperty.Register("PopupWindowType", typeof(PopupWindowTypes), typeof(PopupWindow), new FrameworkPropertyMetadata(new PropertyChangedCallback(PopupWindow.OnPopupWindowTypeChanged)));
		internal Grid Rooty;
		internal ScaleTransform Scaler;

		// Methods
		public PopupWindow()
		{
			this.InitializeComponent();
			base.IsVisibleChanged += new DependencyPropertyChangedEventHandler(this.PopupWindow_IsVisibleChanged);
		}

		private void CloseDialog_Click(object sender, RoutedEventArgs e)
		{
			((Storyboard) base.FindResource("HideWindow")).Begin(this);
		}

		private void Dragger_DragDelta(object sender, DragDeltaEventArgs e)
		{
			base.Left += e.HorizontalChange;
			base.Top += e.VerticalChange;
		}

		private void HideWindow_Completed(object sender, EventArgs e)
		{
			base.Close();
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/popupwindow.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private static void OnPopupWindowTypeChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
		{
			PopupWindow window = d as PopupWindow;
			if (window != null)
			{
				switch (((PopupWindowTypes) e.NewValue))
				{
					case PopupWindowTypes.Information:
						window.ErrorImage.Visibility = Visibility.Collapsed;
						window.InfoImage.Visibility = Visibility.Visible;
						return;
				}
				window.ErrorImage.Visibility = Visibility.Visible;
				window.InfoImage.Visibility = Visibility.Collapsed;
			}
		}

		private void PopupWindow_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
		{
			((Storyboard) base.FindResource("ShowWindow")).Begin(this);
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.mainWin = (PopupWindow) target;
					return;

				case 2:
					((Storyboard) target).Completed += new EventHandler(this.HideWindow_Completed);
					return;

				case 3:
					this.Rooty = (Grid) target;
					return;

				case 4:
					this.Scaler = (ScaleTransform) target;
					return;

				case 5:
					this.ErrorImage = (Image) target;
					return;

				case 6:
					this.InfoImage = (Image) target;
					return;

				case 7:
					((Thumb) target).DragDelta += new DragDeltaEventHandler(this.Dragger_DragDelta);
					return;

				case 8:
					this.CloseDialog = (ImageButton) target;
					this.CloseDialog.Click += new RoutedEventHandler(this.CloseDialog_Click);
					return;
			}
			this._contentLoaded = true;
		}

		// Properties
		public string PopupWindowText
		{
			get
			{
				return (string) base.GetValue(PopupWindowTextProperty);
			}
			set
			{
				base.SetValue(PopupWindowTextProperty, value);
			}
		}

		public PopupWindowTypes PopupWindowType
		{
			get
			{
				return (PopupWindowTypes) base.GetValue(PopupWindowTypeProperty);
			}
			set
			{
				base.SetValue(PopupWindowTypeProperty, value);
			}
		}

		// Nested Types
		public enum PopupWindowTypes
		{
			Error,
			Information
		}
	}
}