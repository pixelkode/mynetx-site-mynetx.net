namespace blu
{
	public static class WordBreaker
	{
		// Methods
		private static TextPointer GetPositionAtWordBoundary(TextPointer position, LogicalDirection wordBreakDirection)
		{
			if (!position.IsAtInsertionPosition)
			{
				position = position.GetInsertionPosition(wordBreakDirection);
			}
			TextPointer nextInsertionPosition = position;
			while ((nextInsertionPosition != null) && !IsPositionNextToWordBreak(nextInsertionPosition, wordBreakDirection))
			{
				nextInsertionPosition = nextInsertionPosition.GetNextInsertionPosition(wordBreakDirection);
			}
			return nextInsertionPosition;
		}

		public static TextRange GetWordRange(TextPointer position)
		{
			TextRange range = null;
			TextPointer pointer = null;
			TextPointer positionAtWordBoundary = null;
			positionAtWordBoundary = GetPositionAtWordBoundary(position, LogicalDirection.Forward);
			if (positionAtWordBoundary != null)
			{
				pointer = GetPositionAtWordBoundary(positionAtWordBoundary, LogicalDirection.Backward);
			}
			if ((pointer != null) && (positionAtWordBoundary != null))
			{
				range = new TextRange(pointer, positionAtWordBoundary);
			}
			return range;
		}

		private static bool IsPositionNextToWordBreak(TextPointer position, LogicalDirection wordBreakDirection)
		{
			bool flag = false;
			if (position.GetPointerContext(wordBreakDirection) != TextPointerContext.Text)
			{
				position = position.GetInsertionPosition(wordBreakDirection);
			}
			if (position.GetPointerContext(wordBreakDirection) == TextPointerContext.Text)
			{
				LogicalDirection direction = (wordBreakDirection == LogicalDirection.Forward) ? LogicalDirection.Backward : LogicalDirection.Forward;
				char[] textBuffer = new char[1];
				char[] chArray2 = new char[1];
				position.GetTextInRun(wordBreakDirection, textBuffer, 0, 1);
				position.GetTextInRun(direction, chArray2, 0, 1);
				if ((textBuffer[0] == ' ') && (chArray2[0] != ' '))
				{
					flag = true;
				}
				return flag;
			}
			return true;
		}
	}
}