namespace blu
{
	[ValueConversion(typeof(bool), typeof(string))]
	public class HasFriendsStringConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			try
			{
				if ((bool) value)
				{
					return "There are no recent tweets from any of your favorite friends.";
				}
			}
			catch
			{
			}
			return "You haven't selected any friends to favorite. Favorited friends will always show their most recent tweet in this view.";
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return false;
		}
	}
}