namespace blu
{
	[ValueConversion(typeof(int), typeof(string))]
	public class BadUserInfoConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			object obj2;
			try
			{
				if (((int) value) == -1)
				{
					return "?";
				}
				obj2 = value.ToString();
			}
			catch
			{
			}
			return obj2;
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return 0.0;
		}
	}
}