namespace blu
{
	public static class HyperlinkHelper
	{
		// Methods
		private static Hyperlink GetHyperlinkAncestor(TextPointer position)
		{
			Inline parent = position.Parent as Inline;
			while ((parent != null) && !(parent is Hyperlink))
			{
				parent = parent.Parent as Inline;
			}
			return (parent as Hyperlink);
		}

		public static bool IsHyperlinkBoundaryCrossed(TextPointer caretPosition, TextPointer backspacePosition, out Hyperlink backspacePositionHyperlink)
		{
			Hyperlink hyperlinkAncestor = GetHyperlinkAncestor(caretPosition);
			backspacePositionHyperlink = GetHyperlinkAncestor(backspacePosition);
			return (((hyperlinkAncestor == null) && (backspacePositionHyperlink != null)) || (((hyperlinkAncestor != null) && (backspacePositionHyperlink != null)) && (hyperlinkAncestor != backspacePositionHyperlink)));
		}

		public static bool IsHyperlinkProperty(DependencyProperty dp)
		{
			if (((dp != Hyperlink.CommandProperty) && (dp != Hyperlink.CommandParameterProperty)) && ((dp != Hyperlink.CommandTargetProperty) && (dp != Hyperlink.NavigateUriProperty)))
			{
				return (dp == Hyperlink.TargetNameProperty);
			}
			return true;
		}

		public static bool IsInHyperlinkScope(TextPointer position)
		{
			return (GetHyperlinkAncestor(position) != null);
		}
	}
}