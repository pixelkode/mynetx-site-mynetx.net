namespace blu
{
	[ValueConversion(typeof(MainWindow.Timelines), typeof(Visibility))]
	public class CurrentTimelineConverter : IValueConverter
	{
		// Methods
		public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
		{
			try
			{
				MainWindow.Timelines timelines = (MainWindow.Timelines) value;
				if (timelines != MainWindow.Timelines.Undefined)
				{
					if (parameter.ToString().Equals("faves", StringComparison.OrdinalIgnoreCase))
					{
						if (timelines == MainWindow.Timelines.FavoriteFriends)
						{
							return Visibility.Visible;
						}
						return Visibility.Hidden;
					}
					if (parameter.ToString().Equals("friends", StringComparison.OrdinalIgnoreCase))
					{
						if (timelines == MainWindow.Timelines.Friends)
						{
							return Visibility.Visible;
						}
						return Visibility.Hidden;
					}
					if (parameter.ToString().Equals("direct", StringComparison.OrdinalIgnoreCase))
					{
						if (timelines == MainWindow.Timelines.DirectMessages)
						{
							return Visibility.Visible;
						}
						return Visibility.Hidden;
					}
					if (timelines == MainWindow.Timelines.Replies)
					{
						return Visibility.Visible;
					}
				}
				return Visibility.Hidden;
			}
			catch
			{
				return MainWindow.Timelines.Undefined;
			}
		}

		public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
		{
			return MainWindow.Timelines.Undefined;
		}
	}
}