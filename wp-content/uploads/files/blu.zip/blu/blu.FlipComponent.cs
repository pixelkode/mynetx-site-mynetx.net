namespace blu
{
	public class FlipComponent : UserControl, IComponentConnector
	{
		// Fields
		private bool _contentLoaded;
		private bool animateItemLocation;
		private FlipContentTypes flipContentType;
		private double lowerExtent = 400.0;
		private double lowerExtentOffset = 10.0;
		private DirectMessage newDirectMessage;
		private Tweet newTweet;
		private FrameworkElement originalContent;
		private TwitterDataListComponent parentControl;
		internal TransitionPresenter Presenter;
		private Rectangle presenterContent = new Rectangle();
		private FlipContentComponent presenterFlippedContent = new FlipContentComponent();
		internal Rectangle Recty;
		private Point returnLocation;
		internal Grid Rooty;

		// Methods
		public FlipComponent()
		{
			AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(this.CurrentDomain_UnhandledException);
			this.InitializeComponent();
			this.HookUpFlipContentEvents();
		}

		private void CancelTweet_Click(object sender, RoutedEventArgs e)
		{
			this.newTweet = null;
			this.newDirectMessage = null;
			this.FlipBack();
		}

		private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
		{
			Exception exceptionObject = e.ExceptionObject as Exception;
			((MainWindow) Application.Current.MainWindow).ShowPopup("blu has encountered an problem. If logging has been turned on, more details are probably in that file.", PopupWindow.PopupWindowTypes.Error);
			bluHelper.WriteToLogger("Unhandled dispatcher exception at flip component level: " + exceptionObject.Message + Environment.NewLine + "StackTrace: " + exceptionObject.StackTrace, 1);
			if (exceptionObject.InnerException != null)
			{
				bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.StackTrace, 1);
				if (exceptionObject.InnerException.InnerException != null)
				{
					bluHelper.WriteToLogger(" - Unhandled dispatcher exception [MORE]: " + exceptionObject.InnerException.InnerException.Message + Environment.NewLine + "StackTrace: " + exceptionObject.InnerException.InnerException.StackTrace, 1);
				}
			}
		}

		private void FlipBack()
		{
			if (this.animateItemLocation)
			{
				this.animateItemLocation = false;
				ThicknessAnimation animation = new ThicknessAnimation(new Thickness(this.returnLocation.X, this.returnLocation.Y, 0.0, 0.0), new Duration(TimeSpan.FromMilliseconds(200.0)));
				animation.DecelerationRatio = 0.9;
				this.Presenter.BeginAnimation(FrameworkElement.MarginProperty, animation);
			}
			this.Recty.IsHitTestVisible = false;
			this.parentControl.EnableList();
			this.presenterContent.Tag = true;
			((RotateTransition) base.FindResource("tpRotater")).set_Direction(1);
			this.Presenter.set_Content(this.presenterContent);
		}

		public void FlipOver(FrameworkElement item, FlipContentTypes type, object dataContext)
		{
			this.presenterFlippedContent.NewTweet.Clear();
			((MainWindow) Application.Current.MainWindow).ComponentIsFlipped = true;
			if (this.parentControl.ShowsUserInfo)
			{
				this.lowerExtent = 55.0;
				this.lowerExtentOffset = 5.0;
			}
			else
			{
				this.lowerExtent = 400.0;
				this.lowerExtentOffset = 10.0;
			}
			this.flipContentType = type;
			this.Recty.IsHitTestVisible = true;
			this.parentControl.DisableList();
			this.originalContent = item;
			this.presenterContent.Width = 302.0;
			this.presenterContent.Height = 70.0;
			this.presenterContent.Fill = new VisualBrush(this.originalContent);
			this.originalContent.RenderTransform = new TranslateTransform(10000.0, 0.0);
			this.presenterContent.Tag = false;
			this.presenterFlippedContent.DataContext = dataContext;
			this.presenterFlippedContent.FlipContentType = type;
			if (type == FlipContentTypes.CreateReply)
			{
				this.presenterFlippedContent.NewTweet.InitializeWithString("@" + ((Tweet) dataContext).get_User().get_ScreenName() + " ");
			}
			else if (type == FlipContentTypes.CreateRetweet)
			{
				this.presenterFlippedContent.NewTweet.InitializeWithString("RT @" + ((Tweet) dataContext).get_User().get_ScreenName() + " " + ((Tweet) dataContext).get_Text());
			}
			this.Presenter.set_Transition(null);
			this.Presenter.set_Content(this.presenterContent);
			this.Presenter.set_Transition(base.FindResource("tpRotater") as RotateTransition);
			((RotateTransition) base.FindResource("tpRotater")).set_Direction(0);
			this.Presenter.Visibility = Visibility.Visible;
			Matrix matrix = (this.originalContent.TransformToVisual(this.parentControl.List) as Transform).Value;
			if (matrix.OffsetY < 25.0)
			{
				this.animateItemLocation = true;
				this.returnLocation = new Point(matrix.OffsetX, matrix.OffsetY);
				ThicknessAnimation animation = new ThicknessAnimation(new Thickness(matrix.OffsetX, matrix.OffsetY, 0.0, 0.0), new Thickness(matrix.OffsetX, 25.0, 0.0, 0.0), new Duration(TimeSpan.FromMilliseconds(250.0)));
				animation.DecelerationRatio = 0.9;
				this.Presenter.BeginAnimation(FrameworkElement.MarginProperty, animation);
			}
			else if (matrix.OffsetY > this.lowerExtent)
			{
				this.animateItemLocation = true;
				this.returnLocation = new Point(matrix.OffsetX, matrix.OffsetY);
				ThicknessAnimation animation2 = new ThicknessAnimation(new Thickness(matrix.OffsetX, matrix.OffsetY, 0.0, 0.0), new Thickness(matrix.OffsetX, this.lowerExtent - this.lowerExtentOffset, 0.0, 0.0), new Duration(TimeSpan.FromMilliseconds(250.0)));
				animation2.DecelerationRatio = 0.9;
				this.Presenter.BeginAnimation(FrameworkElement.MarginProperty, animation2);
			}
			else
			{
				this.animateItemLocation = false;
				this.Presenter.BeginAnimation(FrameworkElement.MarginProperty, null);
				this.Presenter.Margin = new Thickness(matrix.OffsetX, matrix.OffsetY, 0.0, 0.0);
			}
			DispatcherTimer timer = new DispatcherTimer();
			timer.Interval = TimeSpan.FromMilliseconds(1.0);
			timer.Tick += delegate {
				timer.Stop();
				this.Presenter.set_Content(this.presenterFlippedContent);
				this.presenterFlippedContent.BubbleUp();
			};
			timer.Start();
		}

		private void HookUpFlipContentEvents()
		{
			this.presenterFlippedContent.ViewReplyExiter.MouseUp += new MouseButtonEventHandler(this.ViewReplyExiter_MouseUp);
			this.presenterFlippedContent.NewTweet.PreviewKeyDown += new KeyEventHandler(this.NewTweet_PreviewKeyDown);
			this.presenterFlippedContent.SubmitTweet.Click += new RoutedEventHandler(this.SubmitTweet_Click);
			this.presenterFlippedContent.CancelTweet.Click += new RoutedEventHandler(this.CancelTweet_Click);
		}

		[DebuggerNonUserCode]
		public void InitializeComponent()
		{
			if (!this._contentLoaded)
			{
				this._contentLoaded = true;
				Uri resourceLocator = new Uri("/blu;component/controls/flipitems/flipcomponent.xaml", UriKind.Relative);
				Application.LoadComponent(this, resourceLocator);
			}
		}

		private void NewTweet_PreviewKeyDown(object sender, KeyEventArgs e)
		{
			if ((e.Key == Key.Return) || (e.Key == Key.Return))
			{
				this.SubmitTweet_Click(null, null);
			}
		}

		private void Rectangle_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.FlipBack();
		}

		private void Rooty_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.Key == Key.Escape)
			{
				this.FlipBack();
			}
		}

		private void SubmitTweet_Click(object sender, RoutedEventArgs e)
		{
			RunWorkerCompletedEventHandler handler = null;
			if (((this.presenterFlippedContent.NewTweet.TextLength > 0) && (this.presenterFlippedContent.NewTweet.TextLength <= 140)) && ((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				this.FlipBack();
				if ((this.flipContentType == FlipContentTypes.CreateReply) || (this.flipContentType == FlipContentTypes.CreateRetweet))
				{
					this.newDirectMessage = null;
					this.newTweet = new Tweet();
					this.newTweet.set_Text(this.presenterFlippedContent.NewTweet.PlainText);
					this.newTweet.set_ReplyToStatusId(((Tweet) this.presenterFlippedContent.DataContext).get_Id());
				}
				else if (this.flipContentType == FlipContentTypes.CreateDirectMessage)
				{
					this.newTweet = null;
					this.newDirectMessage = new DirectMessage();
					this.newDirectMessage.set_Text(this.presenterFlippedContent.NewTweet.PlainText);
					this.newDirectMessage.set_Recipient(new User());
					if (this.presenterFlippedContent.DataContext is Tweet)
					{
						this.newDirectMessage.get_Recipient().set_Id(((Tweet) this.presenterFlippedContent.DataContext).get_User().get_Id());
					}
					else
					{
						this.newDirectMessage.get_Recipient().set_Id(((DirectMessage) this.presenterFlippedContent.DataContext).get_Sender().get_Id());
					}
				}
				BackgroundWorker worker = new BackgroundWorker();
				worker.DoWork += delegate {
					Thread.Sleep(500);
				};
				if (handler == null)
				{
					handler = delegate {
						if (this.newTweet != null)
						{
							this.parentControl.RaiseCreateEvent(this.newTweet);
						}
						else if (this.newDirectMessage != null)
						{
							this.parentControl.RaiseCreateEvent(this.newDirectMessage);
						}
					};
				}
				worker.RunWorkerCompleted += handler;
				worker.RunWorkerAsync(null);
			}
			else if (!((MainWindow) Application.Current.MainWindow).HasConnectivity)
			{
				((MainWindow) Application.Current.MainWindow).ShowPopup("Can't submit. There's no interweb connectivity.", PopupWindow.PopupWindowTypes.Error);
			}
		}

		[EditorBrowsable(EditorBrowsableState.Never), DebuggerNonUserCode]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
				case 1:
					this.Rooty = (Grid) target;
					this.Rooty.KeyDown += new KeyEventHandler(this.Rooty_KeyDown);
					return;

				case 2:
					this.Recty = (Rectangle) target;
					this.Recty.MouseUp += new MouseButtonEventHandler(this.Rectangle_MouseUp);
					return;

				case 3:
					this.Presenter = (TransitionPresenter) target;
					this.Presenter.add_TransitionCompleted(new RoutedEventHandler(this.tp_TransitionCompleted));
					return;
			}
			this._contentLoaded = true;
		}

		private void tp_TransitionCompleted(object sender, RoutedEventArgs e)
		{
			if ((((FrameworkElement) this.Presenter.get_Content()).Tag is bool) && ((bool) ((FrameworkElement) this.Presenter.get_Content()).Tag))
			{
				ThicknessAnimation animation = new ThicknessAnimation(new Thickness(0.0, 100.0, 0.0, 0.0), new Duration(TimeSpan.FromMilliseconds(0.0)));
				this.Presenter.BeginAnimation(FrameworkElement.MarginProperty, animation);
				this.presenterFlippedContent.BubbleDown();
				this.originalContent.RenderTransform = new TranslateTransform(0.0, 0.0);
				this.Presenter.Visibility = Visibility.Hidden;
				this.Presenter.Tag = null;
				((MainWindow) Application.Current.MainWindow).ComponentIsFlipped = false;
			}
		}

		private void ViewReplyExiter_MouseUp(object sender, MouseButtonEventArgs e)
		{
			this.FlipBack();
		}

		// Properties
		public TwitterDataListComponent ParentControl
		{
			set
			{
				this.parentControl = value;
			}
		}

		// Nested Types
		public enum FlipContentTypes
		{
			Unset,
			ViewReply,
			ViewReplyNotFound,
			ViewReplyPrivate,
			CreateReply,
			CreateDirectMessage,
			CreateRetweet
		}
	}
}