<?php

$hyper_labels['wp_cache_not_enabled'] = "Le cache de WordPress n'est pas activ&eacute;. Merci d'ajouter la ligne suivante dans votre fichier wp-config.php. Merci !";
$hyper_labels['configuration'] = "Configuration";
$hyper_labels['activate'] = "Activer le cache?";
$hyper_labels['expire'] = "Les pages contenues dans le cache expirent apr&egrave;s";
$hyper_labels['minutes'] = "minutes";
$hyper_labels['invalidate_single_posts'] = "Invalidate single posts";
$hyper_labels['invalidate_single_posts_desc'] = "Invalidate only the single cached post when modified (new comment, edited, ...)";
$hyper_labels['count'] = "Total cached pages (cached redirect is counted too)";
$hyper_labels['save'] = "Enregistrer";
$hyper_labels['gzip_compression'] = "Gzip compression";
$hyper_labels['gzip_compression_desc'] = "Enable gzip compression to serve copressed pages for gzip enabled browsers";
$hyper_labels['clear'] = "Effacer le cache";

?>
